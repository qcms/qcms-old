<?
//-----------------------------------------------------------------------------
// Модуль конфигурации БД
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Настройки базы данных
if(preg_match("/".preg_quote("mamin.ru")."/",$_SERVER["HTTP_HOST"]))
{
  // тип БД
  define("DATABASE_TYPE", "mysql");
  // сервер БД
  define("DATABASE_SERVER", "127.0.0.1");
  // имя БД
  define("DATABASE_NAME", "");
  // user
  define("DATABASE_USER", "");
  // password
  define("DATABASE_PW", "");
  // префикс таблиц в БД
  define("DATABASE_PREFIX", "");

  define("DATABASE_CHARSET", "utf8 collate utf8_general_ci");
  define("DATABASE_AFTER_CONNECT", "SET NAMES " . DATABASE_CHARSET);
	
}
elseif(preg_match("/".preg_quote("mamin.infoways.ru")."/",$_SERVER["HTTP_HOST"]))
{
  // тип БД
  define("DATABASE_TYPE", "mysql");
  // сервер БД
  define("DATABASE_SERVER", "db35.valuehost.ru");
  // имя БД
  define("DATABASE_NAME", "quazar30_mami");
  // user
  define("DATABASE_USER", "quazar30_mami");
  // password
  define("DATABASE_PW", "dWdF8p3c");
  // префикс таблиц в БД
  define("DATABASE_PREFIX", "");
  
  define("DATABASE_CHARSET", "utf8 collate utf8_general_ci");
  define("DATABASE_AFTER_CONNECT", "SET NAMES " . DATABASE_CHARSET);
    
}
elseif(preg_match("/".preg_quote("mamin.local")."/",$_SERVER["HTTP_HOST"]))
{
  // тип БД
  define("DATABASE_TYPE", "mysql");
  // сервер БД
  define("DATABASE_SERVER", "127.0.0.1");
  // имя БД
  define("DATABASE_NAME", "mamin");
  // user
  define("DATABASE_USER", "mamin");
  // password
  define("DATABASE_PW", "mamin");
  // префикс таблиц в БД
  define("DATABASE_PREFIX", "");

  define("DATABASE_CHARSET", "utf8 collate utf8_general_ci");
  define("DATABASE_AFTER_CONNECT", "SET NAMES " . DATABASE_CHARSET);
}
else
{
	die("WRONG PARAMS!");
}
?>