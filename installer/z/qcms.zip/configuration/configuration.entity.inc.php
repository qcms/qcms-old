<?
//-----------------------------------------------------------------------------
// Файл конфигурации сущностей базы данных
//-----------------------------------------------------------------------------


//-----------------------------------------------------------------------------
// массивы предопределенных значений
// структура: $arr = array("значение" => array("Название язык 0", "Название язык 1"));
global $user_sexs;
$user_sexs = array(
  "1" => array("Мужчина"),
  "2" => array("Женщина"),
);

global $user_sexs1;
$user_sexs1 = array(
  "1" => array("Мужской"),
  "2" => array("Женский"),
);


global $page_types;
$page_types = array(
  "1" => array("Обычная страница"),
	"2" => array("Модульная страница"),
	//"3" => array("Список потомков"),
	"100" => array("Специальная страница"),
);


global $page_module_types;
$page_module_types = array(
	"1" => array("Текст"),
	"2" => array("Текст с изображениями"),
	"3" => array("Текст с видео"),
	"4" => array("Галерея"),
);



//-----------------------------------------------------------------------------
// описание структуры базы в админке
// массив
// array(
//    "Имя_таблицы_1" => array(
//      "name" => array("Название таблицы язык 0", "Название таблицы язык 1"),
//			"superadmin" => "true",	// признак объекта который доступен только суперадмину
//      "admin" => array(
//        "all" => array(
//          "url_template" =>"шаблон URL-а админки для полного списка элементов",
//          "file"=>"файл админки для полного списка элементов"
//          "name"=> array("Рус. название", "Англ. название")
//        ),
//        "edit" => array(
//          "url_template" =>"шаблон URL-а админки для элемента",
//          "file"=>"файл админки для элемента",
//          "name" => array("Рус. название", "Англ. название")
//        ),
//      	"delete" => array(
//        	"url_template" => "page_edit.php?id=[id]&action=delete",
//        	"file" => "page_edit.php",
//        	"name" => array("Удалить"),
//      	),
//        "list" => array(
//          "url_template" =>"шаблон URL-а админки для списка элементов (специальный)",
//          "file" => "файл админки для списка элементов (специальный)",
//          "name" => array("Рус. название", "Англ. название")
//        ),
//        "action" => array(
//          "file" => "файл специальных действий, должен лежать в каталоге 'admin/boxes/'", // нужен для решения дополнительных задач (блог, и т.п.), обрабатывает POST запросы
//        )
//      ),
//			"hierarchy" => array( // параметры иерархии
//				"hierarchy" => "true",	// признак иерархии в текущей таблице
//				"hierarchy_parent_field" => "field333", // поле текущей таблице для родителя иерархии
//    		"parent" => "true",	// признак подчиненности объекта
//				"parent_table" => "table11",	// таблица родетеля 
//				"parent_field"	=> "",	// поле текущей таблицы для иерархии
//			),
//      "fields" => array(
//        "field1" => array(
//          "name" => array("Название поля язык 0", "Название поля язык 1"),
//          "type" => "string", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file, varchar
//          "params" => array( // параметры поля
//            "default" => array("значение по умолчанию язык 0", "значение по умолчанию язык 1"),
//            "editor" => "true", // признак того что для типа text нужен расширенный редактор
//            "length" => "30", // длина поля для полей типа string, number
//            "hidden" => "true", // поле скрыто
//            "nolang" => "true", // поле одинаково во всех языках, берется значение с индексом [0]
//            "value" => array("1"),     // Обязательное значение для данного поля, если type=="date" и значение == NOW, то устанавливается значение текущей даты
//            "readonly" => "true",   // неизменяемое значение
//            "template" => "true",   // при редактировании выводится шаблон поля
//      			"unique" => "true",			// признак уникальности поля в таблице
//						"dbtype" => "varchar(200)", // специальное описание типа для поля в БД
//            "width" => "640",   // ширина (размер плеера)
//            "height" => "360",   // высота (размер плеера)
//            "preview_field" => "field_name",   // поле для превью в плеере
//            "select" => array( // параметры поля типа select
//              "size" => "1", // size для поля типа select
//              "multiselect" => "true", // возможность множественного выбора для поля типа select
//              "values" => "user_sexs", // значения в переменной  из "массивы предопределенных значений"
//            	"hierarchy" => "true", // признак иерархии
//              "table" => array(
//                "name" => "tablename", // имя таблицы
//                "field" => "fieldname", // имя поля для значений
//                "parentfield" => "parentfieldname", // имя поля родителя в иерархии
//                "namefield"=>"fieldname_name", // имя поля для имен
//	      				"where" => "somefield='somevalue'",		// фильтрация
//      					"where" => "somefield = '[header:somefield]'",		// фильтрация    
//                "orderfield"=>"fieldname_order" // имя поля упорядочивания
//              ),
//            ),
//          ),
//        ),
//      ),
//      "order" => array("field_order1"=>"ASC","field_order2"=>"DESC"), // поля упорядочивания в админке
//      "autoreorder" => "true", // автоматическое переупорядочивание при занесении новой записи
//    ),
//    "Имя_таблицы_2" => array(),
//
// );

global $db_forms;

$db_forms = array(
  "index" => array(
    "name" => array("Главная"),
    "admin" => array(
      "all" => array(
        "url_template" => "index.php",
        "file" => "index.php",
        "name" => array("Главная")
        )
    ),
    "fields" => array(),
    "order" => array() // поля упорядочивания в админке
  ),


  "config" => array(
    "name" => array("Конфигурация"),
    "admin" => array(
      "all" => array(
        "url_template" => "config_all.php",
        "file" => "config_all.php",
        "name" => array("Конфигурация")
        )
    ),
    "superadmin" => "true",	// признак объекта который доступен только суперадмину
    "fields" => array(
      "config_id" => array(
        "name" => array("ID", "ID"),
        "type" => "string", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "default" => array("1"),
          "value" => array("1"),
          "nolang" => "true",
          "hidden" => "true",
          //"readonly" => "true",
          //"editor" => "false", // признак того что для типа text нужен расширенный редактор
          "length" => "30" // длина поля для полей типа string, number
        )
      ),
      "config_site_name" => array(
        "name" => array("Название сайта"),
        "type" => "string", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "default" => array("Тут название сайта"),
          //"editor" => "false", // признак того что для типа text нужен расширенный редактор
          "length" => "30", // длина поля для полей типа string, number
          //"nolang" => "true",
      	)
      ),
      "config_site_keywords" => array(
        "name" => array("Ключевые слова сайта<br />(на всех страницах)"),
        "type" => "text", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "default" => array("Ключевые слова"),
          //"editor" => "false", // признак того что для типа text нужен расширенный редактор
          //"length" => "30", // длина поля для полей типа string, number
          //"nolang" => "true",
      	)
      ),
      "config_site_description" => array(
        "name" => array("Описание сайта<br />(на всех страницах)"),
        "type" => "text", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "default" => array("Описание сайта"),
          //"nolang" => "true",
          //"editor" => "false", // признак того что для типа text нужен расширенный редактор
          //"length" => "30", // длина поля для полей типа string, number
        )
      ),
      "config_site_emailfrom" => array(
        "name" => array("Email с которого сайт посылает сообщения"),
        "type" => "string", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "default" => array(""),
          "nolang" => "true",
          "length" => "30" // длина поля для полей типа string, number
        )
      ),
      "config_site_emailto" => array(
        "name" => array("Email на который сайт посылает сервисные сообщения"),
        "type" => "string", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "default" => array(""),
          "nolang" => "true",
          "length" => "30" // длина поля для полей типа string, number
        )
      ),
      "config_site_isclosed" => array(
        "name" => array("Сайт временно не работает"),
        "type" => "checkbox", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "default" => array(),
          "nolang" => "true"
          //"length" => "30", // длина поля для полей типа string, number
        )
      ),
      "config_site_isclosed_message" => array(
        "name" => array("Сообщение о том что сайт не работет"),
        "type" => "text", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "default" => array("Сайт временно не работает"),
          "editor" => "true", // признак того что для типа text нужен расширенный редактор
          //"nolang" => "true",
      	)
      ),
      "config_datetime" => array(
        "name" => array("Дата/время изменения"),
        "type" => "datetime", // тип поля string, text, number, checkbox, select
        "params" => array( // параметры поля
          "default" => array(),
          "value" => array("NOW")
          //"editor" => "false", // признак того что для типа text нужен расширенный редактор
          //"length" => "30", // длина поля для полей типа string, number
        )
      ),
		),
    "order" => array() // поля упорядочивания в админке
  ),

  "adminuser" => array(
    "name" => array("Администраторы сайта"),
	  "superadmin" => "true",	// признак объекта который доступен только суперадмину
    "admin" => array(
  		"list" => array(
        "url_template" => "adminuser_list.php",
        "file" => "adminuser_list.php",
        "name" => array("Администраторы сайта")
      ),
      "edit" => array(
        "url_template" => "adminuser_edit.php?id=[id]",
        "file" => "adminuser_edit.php",
        "name" => array("Редактирование администратора")
      ),
      "delete" => array(
        "url_template" => "adminuser_edit.php?id=[id]&action=delete",
        "file" => "adminuser_edit.php",
        "name" => array("Удалить"),
      ),
    ),
    "fields" => array(
    	"adminusergroup_id" => array(
        "name" => array("Группа"),
        "type" => "select", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
    			"hidden" => "true", // поле скрыто
          "length" => "30", // длина поля для полей типа string, number
          "nolang" => "true", // поле одинаково во всех языках, берется значение с индексом [0]
          "select" => array( // параметры поля типа select
            "size" => "1", // size для поля типа select
            "multiselect" => "false", // возможность множественного выбора для поля типа select
            "table" => array(
              "name" => "adminusergroup", // имя таблицы
              "field" => "adminusergroup_id", // имя поля для значений
              "namefield"=>"adminusergroup_ln", // имя поля для имен
              "orderfield"=>"adminusergroup_order", // имя поля упорядочивания
            ),
          ),
        ),
    	),
      "adminuser_ln" => array(
        "name" => array("Логин администратора"),
        "type" => "string", // тип поля string, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "length" => "30", // длина поля для полей типа string, number
          "nolang" => "true" // поле одинаково во всех языках, берется значение с индексом [0]
        )
      ),
      "adminuser_password" => array(
        "name" => array("Пароль администратора"),
        "type" => "password", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "length" => "30", // длина поля для полей типа string, number
          "nolang" => "true" // поле одинаково во всех языках, берется значение с индексом [0]
        )
      ),
      "adminuser_fullname" => array(
        "name" => array("Полное имя администратора"),
        "type" => "string", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "length" => "30", // длина поля для полей типа string, number
          "nolang" => "true" // поле одинаково во всех языках, берется значение с индексом [0]
        )
      ),
      "adminuser_comment" => array(
        "name" => array("Комментарий"),
        "type" => "text", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "nolang" => "true" // поле одинаково во всех языках, берется значение с индексом [0]
        )
      ),
      "adminuser_datetime" => array(
        "name" => array("Дата/время изменения"),
        "type" => "datetime", // тип поля string, text, number, checkbox, select
        "params" => array( // параметры поля
          "default" => array(),
          "value" => array("NOW")
          //"editor" => "false", // признак того что для типа text нужен расширенный редактор
          //"length" => "30", // длина поля для полей типа string, number
        )
      ),
      "adminuser_isshow" => array(
        "name" => array("Активен"),
        "type" => "checkbox", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "default" => array(),
          "nolang" => "true"
          //"length" => "30", // длина поля для полей типа string, number
        )
      ),

    ),
    "order" => array("adminuser_order"=>"ASC"), // поля упорядочивания в админке
		"autoreorder" => "true", // автоматическое переупорядочивание при занесении новой записи
  ),

	"adminuser_access" => array(
    "name" => array("Объект доступа"),
	  "superadmin" => "true",	// признак объекта который доступен только суперадмину
  	"admin" => array(
      "list" => array(
        "url_template" => "adminuser_access_list.php",
        "file" => "adminuser_access_list.php",
        "name" => array("Объект доступа")
      ),
      "edit" => array(
        "url_template" => "adminuser_access_edit.php?id=[id]&adminuser_id=[adminuser_id]&adminusergroup_id=[adminusergroup_id]",
        "file" => "adminuser_access_edit.php",
        "name" => array("Редактирование объекта доступа")
      ),
      "delete" => array(
        "url_template" => "adminuser_access_edit.php?id=[id]&adminuser_id=[adminuser_id]&adminusergroup_id=[adminusergroup_id]&action=delete",
        "file" => "adminuser_access_edit.php",
        "name" => array("Удалить")
      ),
			"up" => array(
        "url_template" => "adminuser_access_edit.php?id=[id]&adminuser_id=[adminuser_id]&adminusergroup_id=[adminusergroup_id]&action=up",
				"file" => "adminuser_access_edit.php",
        "name" => array("Вверх")
      ),
      "down" => array(
        "url_template" => "adminuser_access_edit.php?id=[id]&adminuser_id=[adminuser_id]&adminusergroup_id=[adminusergroup_id]&action=down",
        "file" => "adminuser_access_edit.php",
        "name" => array("Вниз")
      ),
    ),
    "fields" => array(
    	"adminuser_id" => array(
        "name" => array("Пользователь"),
        "type" => "select", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "length" => "30", // длина поля для полей типа string, number
          "nolang" => "true", // поле одинаково во всех языках, берется значение с индексом [0]
          "select" => array( // параметры поля типа select
            "size" => "1", // size для поля типа select
            "multiselect" => "false", // возможность множественного выбора для поля типа select
            "table" => array(
              "name" => "adminuser", // имя таблицы
              "field" => "adminuser_id", // имя поля для значений
              "namefield"=>"adminuser_ln", // имя поля для имен
              "orderfield"=>"adminuser_order", // имя поля упорядочивания
            ),
          ),
        ),
    	),    
      "adminuser_access_entity" => array(
        "name" => array("Объект"),
        "type" => "string", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "length" => "30", // длина поля для полей типа string, number
          "nolang" => "true", // поле одинаково во всех языках, берется значение с индексом [0]
        	"readonly" => "true",
    		)
      ),    
      "adminuser_access_ishierarchisch" => array(
        "name" => array("С учетом иерархии объектов<br /><font size='-2'>Если у доступ к родителю запрещен, то доступ к объекту также запрещен.</font>"),
        "type" => "checkbox", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "default" => array(),
          "nolang" => "true"
          //"length" => "30", // длина поля для полей типа string, number
        )
      ),
      "adminuser_access_isread" => array(
        "name" => array("Разрешен просмотр"),
        "type" => "checkbox", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
				"params" => array( // параметры поля
          "nolang" => "true", // поле одинаково во всех языках, берется значение с индексом [0]
        )
      ),    
      "adminuser_access_iswrite" => array(
        "name" => array("Разрешено изменение"),
        "type" => "checkbox", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
				"params" => array( // параметры поля
          "nolang" => "true", // поле одинаково во всех языках, берется значение с индексом [0]
        )
      ),    
      "adminuser_access_isadd" => array(
        "name" => array("Разрешено добавление"),
        "type" => "checkbox", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
				"params" => array( // параметры поля
          "nolang" => "true", // поле одинаково во всех языках, берется значение с индексом [0]
        )
      ),    
      "adminuser_access_isdelete" => array(
        "name" => array("Разрешено удаление"),
        "type" => "checkbox", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
				"params" => array( // параметры поля
          "nolang" => "true", // поле одинаково во всех языках, берется значение с индексом [0]
        )
      ),    
      
      "adminuser_access_isshow" => array(
        "name" => array("Активен"),
        "type" => "checkbox", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "default" => array(),
          "nolang" => "true"
          //"length" => "30", // длина поля для полей типа string, number
        )
      ),
		),
    "order" => array("adminuser_access_order"=>"ASC"), // поля упорядочивания в админке
		"autoreorder" => "true", // автоматическое переупорядочивание при занесении новой записи
	),
  
	"adminuser_access_condition" => array(
    "name" => array("Условия/разрешения "),
	  "superadmin" => "true",	// признак объекта который доступен только суперадмину
  	"admin" => array(
      "list" => array(
        "url_template" => "adminuser_access_condition_list.php",
        "file" => "adminuser_access_condition_list.php",
        "name" => array("Условия/разрешения для объекта")
      ),
      "edit" => array(
        "url_template" => "adminuser_access_condition_edit.php?id=[id]&adminuser_id=[adminuser_id]&adminusergroup_id=[adminusergroup_id]&adminuser_access_id=[adminuser_access_id]",
        "file" => "adminuser_access_condition_edit.php",
        "name" => array("Редактирование условия/разрешения")
      ),
      "delete" => array(
        "url_template" => "adminuser_access_condition_edit.php?id=[id]&adminuser_id=[adminuser_id]&adminusergroup_id=[adminusergroup_id]&adminuser_access_id=[adminuser_access_id]&action=delete",
        "file" => "adminuser_access_condition_edit.php",
        "name" => array("Удалить")
      ),
      "up" => array(
        "url_template" => "adminuser_access_condition_edit.php?id=[id]&adminuser_id=[adminuser_id]&adminusergroup_id=[adminusergroup_id]&adminuser_access_id=[adminuser_access_id]&action=up",
				"file" => "adminuser_access_condition_edit.php",
        "name" => array("Вверх")
      ),
      "down" => array(
        "url_template" => "adminuser_access_condition_edit.php?id=[id]&adminuser_id=[adminuser_id]&adminusergroup_id=[adminusergroup_id]&adminuser_access_id=[adminuser_access_id]&action=down",
        "file" => "adminuser_access_condition_edit.php",
        "name" => array("Вниз")
      ),
  
    ),
    "fields" => array(
    	"adminuser_access_id" => array(
        "name" => array("Объект доступа"),
        "type" => "select", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "length" => "30", // длина поля для полей типа string, number
          "nolang" => "true", // поле одинаково во всех языках, берется значение с индексом [0]
          "select" => array( // параметры поля типа select
            "size" => "1", // size для поля типа select
            "multiselect" => "false", // возможность множественного выбора для поля типа select
            "table" => array(
              "name" => "adminuser_access", // имя таблицы
              "field" => "adminuser_access_id", // имя поля для значений
              "namefield"=>"adminuser_access_entity", // имя поля для имен
              "orderfield"=>"adminuser_access_order", // имя поля упорядочивания
            ),
          ),
        ),
    	),    
      "adminuser_access_condition_field" => array(
        "name" => array("Поле объекта"),
        "type" => "string", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "length" => "30", // длина поля для полей типа string, number
          "nolang" => "true" // поле одинаково во всех языках, берется значение с индексом [0]
        )
      ),    
      "adminuser_access_condition_value" => array(
        "name" => array("Значение поля"),
        "type" => "string", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "length" => "30", // длина поля для полей типа string, number
          "nolang" => "true" // поле одинаково во всех языках, берется значение с индексом [0]
        )
      ),    
      "adminuser_access_condition_ishierarchisch" => array(
        "name" => array("С учетом иерархии объектов"),
        "type" => "checkbox", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "default" => array(),
          "nolang" => "true"
          //"length" => "30", // длина поля для полей типа string, number
        )
      ),
      "adminuser_access_condition_isread" => array(
        "name" => array("Разрешен просмотр"),
        "type" => "checkbox", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
				"params" => array( // параметры поля
          "nolang" => "true", // поле одинаково во всех языках, берется значение с индексом [0]
        )
      ),    
      "adminuser_access_condition_iswrite" => array(
        "name" => array("Разрешено изменение"),
        "type" => "checkbox", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
				"params" => array( // параметры поля
          "nolang" => "true", // поле одинаково во всех языках, берется значение с индексом [0]
        )
      ),    
      "adminuser_access_condition_isadd" => array(
        "name" => array("Разрешено добавление"),
        "type" => "checkbox", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
				"params" => array( // параметры поля
          "nolang" => "true", // поле одинаково во всех языках, берется значение с индексом [0]
        )
      ),    
      "adminuser_access_condition_isdelete" => array(
        "name" => array("Разрешено удаление"),
        "type" => "checkbox", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
				"params" => array( // параметры поля
          "nolang" => "true", // поле одинаково во всех языках, берется значение с индексом [0]
        )
      ),    
			"adminuser_access_condition_isshow" => array(
        "name" => array("Активен"),
        "type" => "checkbox", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "default" => array(),
          "nolang" => "true"
          //"length" => "30", // длина поля для полей типа string, number
        )
      ),
    ),
		"autoreorder" => "true", // автоматическое переупорядочивание при занесении новой записи
    
  ),
  
  "adminusergroup" => array(
    "name" => array("Группы администраторов"),
	  "superadmin" => "true",	// признак объекта который доступен только суперадмину
  	"admin" => array(
//      "all" => array(
//        "url_template" => "adminusergroup_all.php",
//        "file" => "adminusergroup_all.php",
//        "name" => array("Администраторы")
//      ),
      "edit" => array(
        "url_template" => "adminusergroup_edit.php?id=[id]",
        "file" => "adminusergroup_edit.php",
        "name" => array("Редактирование группы")
      ),
      "delete" => array(
        "url_template" => "adminusergroup_edit.php?id=[id]&action=delete",
        "file" => "adminusergroup_edit.php",
        "name" => array("Удалить")
      ),
    ),
    "fields" => array(
      "adminusergroup_ln" => array(
        "name" => array("Код группы"),
        "type" => "string", // тип поля string, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "length" => "30", // длина поля для полей типа string, number
          "nolang" => "true" // поле одинаково во всех языках, берется значение с индексом [0]
        )
      ),
      "adminusergroup_comment" => array(
        "name" => array("Комментарий"),
        "type" => "text", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "nolang" => "true" // поле одинаково во всех языках, берется значение с индексом [0]
        )
      ),
      "adminusergroup_datetime" => array(
        "name" => array("Дата/время изменения"),
        "type" => "datetime", // тип поля string, text, number, checkbox, select
        "params" => array( // параметры поля
          "default" => array(),
          "value" => array("NOW")
          //"editor" => "false", // признак того что для типа text нужен расширенный редактор
          //"length" => "30", // длина поля для полей типа string, number
        )
      ),
      "adminusergroup_isshow" => array(
        "name" => array("Активен"),
        "type" => "checkbox", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "default" => array(),
          "nolang" => "true"
          //"length" => "30", // длина поля для полей типа string, number
        )
      ),
    ),
    "order" => array("adminusergroup_order"=>"ASC"), // поля упорядочивания в админке
		"autoreorder" => "true", // автоматическое переупорядочивание при занесении новой записи
    
  ),
  
	"adminusergroup_access" => array(
    "name" => array("Доступ"),
	  "superadmin" => "true",	// признак объекта который доступен только суперадмину
  	"admin" => array(
//      "list" => array(
//        "url_template" => "adminusergroup_access_list.php",
//        "file" => "adminusergroup_access_list.php",
//        "name" => array("Доступ")
//      ),
//      "edit" => array(
//        "url_template" => "adminusergroup_access_edit.php?id=[id]&adminusergroup_id=[adminusergroup_id]",
//        "file" => "adminusergroup_access_edit.php",
//        "name" => array("Редактирование доступа")
//      ),
    ),
    "fields" => array(
    	"adminusergroup_id" => array(
        "name" => array("Группа"),
        "type" => "select", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "length" => "30", // длина поля для полей типа string, number
          "nolang" => "true", // поле одинаково во всех языках, берется значение с индексом [0]
          "select" => array( // параметры поля типа select
            "size" => "1", // size для поля типа select
            "multiselect" => "false", // возможность множественного выбора для поля типа select
            "table" => array(
              "name" => "adminusergroup", // имя таблицы
              "field" => "adminusergroup_id", // имя поля для значений
              "namefield"=>"adminusergroup_ln", // имя поля для имен
              "orderfield"=>"adminusergroup_order", // имя поля упорядочивания
            ),
          ),
        ),
    	),    
      "adminuser_access_entity" => array(
        "name" => array("Объект"),
        "type" => "string", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "length" => "30", // длина поля для полей типа string, number
          "nolang" => "true" // поле одинаково во всех языках, берется значение с индексом [0]
        )
      ),    
      "adminuser_access_access" => array(
        "name" => array("Доступ"),
        "type" => "string", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "length" => "30", // длина поля для полей типа string, number
          "nolang" => "true" // поле одинаково во всех языках, берется значение с индексом [0]
        )
      ),    
		),
		"autoreorder" => "true", // автоматическое переупорядочивание при занесении новой записи
  ),

  "page" => array(
    "name" => array("Страницы сайта"),
    "admin" => array(
      "all" => array(
        "url_template" => "page_all.php",
        "file" => "page_all.php",
        "name" => array("Страницы сайта"),
      ),
      "edit" => array(
        "url_template" => "page_edit.php?id=[id]",
        "file" => "page_edit.php",
        "name" => array("Редактирование страницы"),
      ),
      "delete" => array(
        "url_template" => "page_edit.php?id=[id]&action=delete",
        "file" => "page_edit.php",
        "name" => array("Удалить"),
      ),
      "up" => array(
        "url_template" => "page_edit.php?id=[id]&action=up",
        "file" => "page_all.php",
        "name" => array("Вверх")
      ),
      "down" => array(
        "url_template" => "page_edit.php?id=[id]&action=down",
        "file" => "page_all.php",
        "name" => array("Вниз")
      )
    ),
		"hierarchy" => array( // параметры иерархии
			"hierarchy" => "true",	// признак иерархии в текущей таблице
			"hierarchy_parent_field" => "page_parent", // поле текущей таблице для родителя иерархии
		),
    "fields" => array(
      "page_name" => array(
        "name" => array("Название страницы"),
        "type" => "string", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "length" => "30", // длина поля для полей типа string, number
          //"nolang" => "true",
				)
      ),
      "page_header_image" => array(
        "name" => array("Изображение шапки страницы"),
        "type" => "image", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "nolang" => "true",
      	)
      ),
      "page_parent" => array(
        "name" => array("Родитель страницы"),
        "type" => "select", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "length" => "30", // длина поля для полей типа string, number
          "nolang" => "true", // поле одинаково во всех языках, берется значение с индексом [0]
          "select" => array( // параметры поля типа select
            "size" => "1", // size для поля типа select
            "multiselect" => "false", // возможность множественного выбора для поля типа select
            "hierarchy" => "true", // признак иерархии
            "table" => array(
              "name" => "page", // имя таблицы
              "field" => "page_id", // имя поля для значений
      				"parentfield" => "page_parent", // имя поля родителя в иерархии
              "namefield"=>"page_name", // имя поля для имен
              "orderfield"=>"page_order" // имя поля упорядочивания
            )
          )
        )
      ),
      "page_type" => array(
        "name" => array("Тип страницы"),
        "type" => "select", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "default" => array(),
          "nolang" => "true",
          "length" => "30", // длина поля для полей типа string, number
          "select" => array( // параметры поля типа select
            "size" => "1", // size для поля типа select
            "multiselect" => "false", // возможность множественного выбора для поля типа select
            "values" => "page_types", // значения в переменной  из "массивы предопределенных значений"
          )
        )
      ),
      "page_description" => array(
        "name" => array("Описание страницы"),
        "type" => "text", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          //"nolang" => "true",
      	)
      ),
      "page_keywords" => array(
        "name" => array("Ключевые слова страницы"),
        "type" => "text", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          //"nolang" => "true",
      	)
      ),
      "page_text" => array(
        "name" => array("Текст страницы"),
        "type" => "text", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          //"nolang" => "true",
      		"editor" => "true", // признак того что для типа text нужен расширенный редактор
        )
      ),
      "page_ln" => array(
        "name" => array("Мнемокод страницы"),
        "type" => "string", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "nolang" => "true",
        )
      ),
      "page_link" => array(
        "name" => array("Ссылка на страницу (внешняя ссылка)"),
        "type" => "string", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "nolang" => "true",
        )
      ),
      "page_ismainmenu" => array(
        "name" => array("Показывать в главном меню"),
        "type" => "checkbox", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "default" => array(),
          "nolang" => "true",
          //"length" => "30", // длина поля для полей типа string, number
        )
      ),
      "page_mainmenu_name" => array(
        "name" => array("Название в главном меню"),
        "type" => "string", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "default" => array(),
          //"nolang" => "true"
          //"length" => "30", // длина поля для полей типа string, number
        )
      ),
      "page_isshowsubmenu" => array(
        "name" => array("Показывать субменю"),
        "type" => "checkbox", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "default" => array(),
          "nolang" => "true",
          //"length" => "30", // длина поля для полей типа string, number
        )
      ),
      "page_isshowvideo" => array(
        "name" => array("Показывать видео"),
        "type" => "checkbox", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "default" => array(),
          "nolang" => "true",
          //"length" => "30", // длина поля для полей типа string, number
        )
      ),
      "page_video_moto" => array(
        "name" => array("Девиз, слева от видео (306x280px)"),
        "type" => "image", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          //"nolang" => "true",
      	)
      ),
      "page_video_preview" => array(
        "name" => array("Превью для видео страницы <br />(640x360px)"),
        "type" => "image", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "nolang" => "true",
      	)
      ),
      "page_video" => array(
        "name" => array("Видео страницы <br />(640x340px)"),
        "type" => "video", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "nolang" => "true",
					"width" => "640",   // ширина (размер плеера)
					"height" => "360",   // высота (размер плеера)
					"preview_field" => "page_video_preview",   // поле для превью в плеере
      
      	)
      ),
      "page_islocked" => array(
        "name" => array("Страница заблокированна"),
        "type" => "checkbox", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "default" => array(),
          "nolang" => "true",
          //"length" => "30", // длина поля для полей типа string, number
        )
      ),
      "page_isshow" => array(
        "name" => array("Показывать страницу"),
        "type" => "checkbox", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "default" => array(),
          "nolang" => "true",
          //"length" => "30", // длина поля для полей типа string, number
        )
      ),
      "page_datetime_create" => array(
        "name" => array("Дата/время создания"),
        "type" => "datetime", // тип поля string, text, number, checkbox, select
        "params" => array( // параметры поля
          "default" => array(),
          //"value" => array("NOW")
        )
      ),
      "page_datetime" => array(
        "name" => array("Дата/время изменения"),
        "type" => "datetime", // тип поля string, text, number, checkbox, select
        "params" => array( // параметры поля
          "default" => array(),
          "value" => array("NOW")
        )
      ),
    ),
    "order" => array("page_order" => "ASC"), // поля упорядочивания в админке
		"autoreorder" => "true", // автоматическое переупорядочивание при занесении новой записи
  ),
  
  "page_module" => array(
    "name" => array("Модули страницы"),
    "admin" => array(
      "list" => array(
        "url_template" => "page_module_list.php",
        "file" => "page_module_list.php",
        "name" => array("Модули")
      ),
      "edit" => array(
        "url_template" => "page_module_edit.php?id=[id]&page_id=[page_id]",
        "file" => "page_module_edit.php",
        "name" => array("Редактирование модуля")
      ),
      "delete" => array(
        "url_template" => "page_module_edit.php?id=[id]&page_id=[page_id]&action=delete",
        "file" => "page_module_edit.php",
        "name" => array("Удалить")
      ),
      "up" => array(
        "url_template" => "page_module_edit.php?id=[id]&action=up&page_id=[page_id]",
        "file" => "page_module_edit.php",
        "name" => array("Вверх", "Up")
      ),
      "down" => array(
        "url_template" => "page_module_edit.php?id=[id]&action=down&page_id=[page_id]",
        "file" => "page_module_edit.php",
        "name" => array("Вниз", "Down")
      )
    ),
		"hierarchy" => array( // параметры иерархии
    	"parent" => "true",	// признак подчиненности объекта
			"parent_table" => "page",	// таблица родетеля 
			"parent_field"	=> "page_id",	// поле текущей таблицы для иерархии
		),
    "fields" => array(
      "page_id" => array(
        "name" => array("Страница"),
        "type" => "select", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "length" => "30", // длина поля для полей типа string, number
          "nolang" => "true", // поле одинаково во всех языках, берется значение с индексом [0]
          "select" => array( // параметры поля типа select
            "size" => "1", // size для поля типа select
            "multiselect" => "false", // возможность множественного выбора для поля типа select
            "table" => array(
              "name" => "page", // имя таблицы
              "field" => "page_id", // имя поля для значений
              "namefield"=>"page_name", // имя поля для имен
							"where" => "",		// фильтрация
    					//"orderfield"=>"page_order ASC" // имя поля упорядочивания
            )
          )
        )
      ),
      "page_module_type" => array(
        "name" => array("Тип модуля"),
        "type" => "select", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "default" => array(),
          "nolang" => "true",
          "length" => "30", // длина поля для полей типа string, number
          "select" => array( // параметры поля типа select
            "size" => "1", // size для поля типа select
            "multiselect" => "false", // возможность множественного выбора для поля типа select
            "values" => "page_module_types", // значения в переменной  из "массивы предопределенных значений"
          )
        )
      ),
      "page_module_name" => array(
        "name" => array("Название"),
        "type" => "string", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "length" => "30", // длина поля для полей типа string, number
          //"nolang" => "true", // поле одинаково во всех языках, берется значение с индексом [0]
	      )
      ),
//      "page_module_video_preview" => array(
//        "name" => array("Превью видео (480x360px)"),
//        "type" => "image", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
//        "params" => array( // параметры поля
//          "nolang" => "true",
//      	)
//      ),
//      "page_module_video" => array(
//        "name" => array("Видео"),
//        "type" => "video", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
//        "params" => array( // параметры поля
//          "nolang" => "true",
//      	)
//      ),
      "page_module_text" => array(
        "name" => array("Текст"),
        "type" => "text", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "editor" => "true", // признак того что для типа text нужен расширенный редактор
          //"nolang" => "true", // поле одинаково во всех языках, берется значение с индексом [0]
        )
      ),
      "page_module_datetime" => array(
        "name" => array("Дата/время изменения"),
        "type" => "datetime", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "default" => array(),
          "value" => array("NOW")
          //"editor" => "false", // признак того что для типа text нужен расширенный редактор
          //"length" => "30", // длина поля для полей типа string, number
        )
      ),
      "page_module_isshow" => array(
        "name" => array("Показывать"),
        "type" => "checkbox", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "default" => array(),
          "nolang" => "true",
          //"length" => "30", // длина поля для полей типа string, number
        )
      ),
    ),
    "order" => array("page_module_order"=>"ASC"), // поля упорядочивания в админке
		"autoreorder" => "true", // автоматическое переупорядочивание при занесении новой записи
  ),

  "page_module_text_image" => array(
    "name" => array("Изображения в тексте"),
    "admin" => array(
      "list" => array(
        "url_template" => "page_module_text_image_list.php",
        "file" => "page_module_text_image_list.php",
        "name" => array("Изображения в тексте")
      ),
      "edit" => array(
        "url_template" => "page_module_text_image_edit.php?id=[id]&page_module_id=[page_module_id]&page_id=[page_id]",
        "file" => "page_module_text_image_edit.php",
        "name" => array("Редактирование изображения")
      ),
      "delete" => array(
        "url_template" => "page_module_text_image_edit.php?id=[id]&page_module_id=[page_module_id]&page_id=[page_id]&action=delete",
        "file" => "page_module_text_image_edit.php",
        "name" => array("Удалить")
      ),
      "up" => array(
        "url_template" => "page_module_text_image_edit.php?id=[id]&action=up&page_module_id=[page_module_id]&page_id=[page_id]",
        "file" => "page_module_text_image_edit.php",
        "name" => array("Вверх", "Up")
      ),
      "down" => array(
        "url_template" => "page_module_text_image_edit.php?id=[id]&action=down&page_module_id=[page_module_id]&page_id=[page_id]",
        "file" => "page_module_text_image_edit.php",
        "name" => array("Вниз", "Down")
      )
    ),
		"hierarchy" => array( // параметры иерархии
    	"parent" => "true",	// признак подчиненности объекта
			"parent_table" => "page_module",	// таблица родетеля 
			"parent_field"	=> "page_module_id",	// поле текущей таблицы для иерархии
		),
    "fields" => array(
      "page_module_id" => array(
        "name" => array("Модуль"),
        "type" => "select", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "length" => "30", // длина поля для полей типа string, number
          "nolang" => "true", // поле одинаково во всех языках, берется значение с индексом [0]
          "select" => array( // параметры поля типа select
            "size" => "1", // size для поля типа select
            "multiselect" => "false", // возможность множественного выбора для поля типа select
            "table" => array(
              "name" => "page_module", // имя таблицы
              "field" => "page_module_id", // имя поля для значений
              "namefield"=>"page_module_name", // имя поля для имен
							"where" => "",		// фильтрация
    					//"orderfield"=>"page_order ASC" // имя поля упорядочивания
            )
          )
        )
      ),
      "page_module_text_image_name" => array(
        "name" => array("Название изображения"),
        "type" => "string", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "length" => "30", // длина поля для полей типа string, number
          //"nolang" => "true", // поле одинаково во всех языках, берется значение с индексом [0]
	      )
      ),
      "page_module_text_image_preview" => array(
        "name" => array("Превью (300x200px)"),
        "type" => "image", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "nolang" => "true",
      	)
      ),
      "page_module_text_image_picture" => array(
        "name" => array("Изображение"),
        "type" => "image", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "nolang" => "true",
      	)
      ),
      "page_module_text_image_datetime" => array(
        "name" => array("Дата/время изменения"),
        "type" => "datetime", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "default" => array(),
          "value" => array("NOW")
          //"editor" => "false", // признак того что для типа text нужен расширенный редактор
          //"length" => "30", // длина поля для полей типа string, number
        )
      ),
      "page_module_text_image_isshow" => array(
        "name" => array("Показывать"),
        "type" => "checkbox", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "default" => array(),
          "nolang" => "true",
          //"length" => "30", // длина поля для полей типа string, number
        )
      ),
    ),
    "order" => array("page_module_text_image_order"=>"ASC"), // поля упорядочивания в админке
		"autoreorder" => "true", // автоматическое переупорядочивание при занесении новой записи
  ),

  "page_module_text_video" => array(
    "name" => array("Видео в тексте"),
    "admin" => array(
      "list" => array(
        "url_template" => "page_module_text_video_list.php",
        "file" => "page_module_text_video_list.php",
        "name" => array("Видео в тексте")
      ),
      "edit" => array(
        "url_template" => "page_module_text_video_edit.php?id=[id]&page_module_id=[page_module_id]&page_id=[page_id]",
        "file" => "page_module_text_video_edit.php",
        "name" => array("Редактирование видео")
      ),
      "delete" => array(
        "url_template" => "page_module_text_video_edit.php?id=[id]&page_module_id=[page_module_id]&page_id=[page_id]&action=delete",
        "file" => "page_module_text_video_edit.php",
        "name" => array("Удалить")
      ),
      "up" => array(
        "url_template" => "page_module_text_video_edit.php?id=[id]&action=up&page_module_id=[page_module_id]&page_id=[page_id]",
        "file" => "page_module_text_video_edit.php",
        "name" => array("Вверх", "Up")
      ),
      "down" => array(
        "url_template" => "page_module_text_video_edit.php?id=[id]&action=down&page_module_id=[page_module_id]&page_id=[page_id]",
        "file" => "page_module_text_video_edit.php",
        "name" => array("Вниз", "Down")
      )
    ),
		"hierarchy" => array( // параметры иерархии
    	"parent" => "true",	// признак подчиненности объекта
			"parent_table" => "page_module",	// таблица родетеля 
			"parent_field"	=> "page_module_id",	// поле текущей таблицы для иерархии
		),
    "fields" => array(
      "page_module_id" => array(
        "name" => array("Модуль"),
        "type" => "select", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "length" => "30", // длина поля для полей типа string, number
          "nolang" => "true", // поле одинаково во всех языках, берется значение с индексом [0]
          "select" => array( // параметры поля типа select
            "size" => "1", // size для поля типа select
            "multiselect" => "false", // возможность множественного выбора для поля типа select
            "table" => array(
              "name" => "page_module", // имя таблицы
              "field" => "page_module_id", // имя поля для значений
              "namefield"=>"page_module_name", // имя поля для имен
							"where" => "",		// фильтрация
    					//"orderfield"=>"page_order ASC" // имя поля упорядочивания
            )
          )
        )
      ),
      "page_module_text_video_name" => array(
        "name" => array("Название видео"),
        "type" => "string", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "length" => "30", // длина поля для полей типа string, number
          //"nolang" => "true", // поле одинаково во всех языках, берется значение с индексом [0]
	      )
      ),
      "page_module_text_video_preview" => array(
        "name" => array("Превью (300x200px)"),
        "type" => "image", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "nolang" => "true",
      	)
      ),
      "page_module_text_video_video" => array(
        "name" => array("Видео (640x340px)"),
        "type" => "video", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "nolang" => "true",
					"width" => "640",   // ширина (размер плеера)
					"height" => "360",   // высота (размер плеера)
					"preview_field" => "page_module_text_video_preview",   // поле для превью в плеере
      	)
      ),
      "page_module_text_video_datetime" => array(
        "name" => array("Дата/время изменения"),
        "type" => "datetime", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "default" => array(),
          "value" => array("NOW")
          //"editor" => "false", // признак того что для типа text нужен расширенный редактор
          //"length" => "30", // длина поля для полей типа string, number
        )
      ),
      "page_module_text_video_isshow" => array(
        "name" => array("Показывать"),
        "type" => "checkbox", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "default" => array(),
          "nolang" => "true",
          //"length" => "30", // длина поля для полей типа string, number
        )
      ),
    ),
    "order" => array("page_module_text_video_order"=>"ASC"), // поля упорядочивания в админке
		"autoreorder" => "true", // автоматическое переупорядочивание при занесении новой записи
  ),
  
  
  "page_module_gallery" => array(
    "name" => array("Изображения в галерее"),
    "admin" => array(
      "list" => array(
        "url_template" => "page_module_gallery_list.php",
        "file" => "page_module_gallery_list.php",
        "name" => array("Изображения в галерее")
      ),
      "edit" => array(
        "url_template" => "page_module_gallery_edit.php?id=[id]&page_module_id=[page_module_id]&page_id=[page_id]",
        "file" => "page_module_gallery_edit.php",
        "name" => array("Редактирование изображения")
      ),
      "delete" => array(
        "url_template" => "page_module_gallery_edit.php?id=[id]&page_module_id=[page_module_id]&page_id=[page_id]&action=delete",
        "file" => "page_module_gallery_edit.php",
        "name" => array("Удалить")
      ),
      "up" => array(
        "url_template" => "page_module_gallery_edit.php?id=[id]&action=up&page_module_id=[page_module_id]&page_id=[page_id]",
        "file" => "page_module_gallery_edit.php",
        "name" => array("Вверх", "Up")
      ),
      "down" => array(
        "url_template" => "page_module_gallery_edit.php?id=[id]&action=down&page_module_id=[page_module_id]&page_id=[page_id]",
        "file" => "page_module_gallery_edit.php",
        "name" => array("Вниз", "Down")
      )
    ),
		"hierarchy" => array( // параметры иерархии
    	"parent" => "true",	// признак подчиненности объекта
			"parent_table" => "page_module",	// таблица родетеля 
			"parent_field"	=> "page_module_id",	// поле текущей таблицы для иерархии
		),
    "fields" => array(
      "page_module_id" => array(
        "name" => array("Модуль"),
        "type" => "select", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "length" => "30", // длина поля для полей типа string, number
          "nolang" => "true", // поле одинаково во всех языках, берется значение с индексом [0]
          "select" => array( // параметры поля типа select
            "size" => "1", // size для поля типа select
            "multiselect" => "false", // возможность множественного выбора для поля типа select
            "table" => array(
              "name" => "page_module", // имя таблицы
              "field" => "page_module_id", // имя поля для значений
              "namefield"=>"page_module_name", // имя поля для имен
							"where" => "",		// фильтрация
    					//"orderfield"=>"page_order ASC" // имя поля упорядочивания
            )
          )
        )
      ),
      "page_module_gallery_name" => array(
        "name" => array("Название изображения"),
        "type" => "string", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "length" => "30", // длина поля для полей типа string, number
          //"nolang" => "true", // поле одинаково во всех языках, берется значение с индексом [0]
	      )
      ),
      "page_module_gallery_preview" => array(
        "name" => array("Превью 150x200px"),
        "type" => "image", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "nolang" => "true",
      	)
      ),
      "page_module_gallery_picture" => array(
        "name" => array("Изображение"),
        "type" => "image", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "nolang" => "true",
      	)
      ),
      "page_module_gallery_datetime" => array(
        "name" => array("Дата/время изменения"),
        "type" => "datetime", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "default" => array(),
          "value" => array("NOW")
          //"editor" => "false", // признак того что для типа text нужен расширенный редактор
          //"length" => "30", // длина поля для полей типа string, number
        )
      ),
      "page_module_gallery_isshow" => array(
        "name" => array("Показывать"),
        "type" => "checkbox", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "default" => array(),
          "nolang" => "true",
          //"length" => "30", // длина поля для полей типа string, number
        )
      ),
    ),
    "order" => array("page_module_gallery_order"=>"ASC"), // поля упорядочивания в админке
		"autoreorder" => "true", // автоматическое переупорядочивание при занесении новой записи
  ),
  
  
  "module" => array(
    "name" => array("Модули сайта"),
    "admin" => array(
      "all" => array(
        "url_template" => "module_all.php",
        "file" => "module_all.php",
        "name" => array("Модули сайта"),
      ),
      "edit" => array(
        "url_template" => "module_edit.php?id=[id]",
        "file" => "module_edit.php",
        "name" => array("Редактирование Модуля"),
      ),
      "delete" => array(
        "url_template" => "module_edit.php?id=[id]&action=delete",
        "file" => "module_edit.php",
        "name" => array("Удалить"),
      ),
      "up" => array(
        "url_template" => "module_edit.php?id=[id]&action=up",
        "file" => "module_all.php",
        "name" => array("Вверх")
      ),
      "down" => array(
        "url_template" => "module_edit.php?id=[id]&action=down",
        "file" => "module_all.php",
        "name" => array("Вниз")
      )
    ),
    "fields" => array(
//      "module_type" => array(
//        "name" => array("Тип модуля"),
//        "type" => "select", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
//        "params" => array( // параметры поля
//          "default" => array(),
//          "nolang" => "true",
//          "length" => "30", // длина поля для полей типа string, number
//          "select" => array( // параметры поля типа select
//            "size" => "1", // size для поля типа select
//            "multiselect" => "false", // возможность множественного выбора для поля типа select
//            "values" => "module_types", // значения в переменной  из "массивы предопределенных значений"
//          )
//        )
//      ),    
			"module_ln" => array(
        "name" => array("Мнемокод модуля"),
        "type" => "string", // тип поля string, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "length" => "30", // длина поля для полей типа string, number
          "nolang" => "true" // поле одинаково во всех языках, берется значение с индексом [0]
        )
      ),
      "module_link" => array(
        "name" => array("Ссылка на модуль"),
        "type" => "string", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "length" => "30", // длина поля для полей типа string, number
          "nolang" => "true" // поле одинаково во всех языках, берется значение с индексом [0]
        )
      ),
      "module_name" => array(
        "name" => array("Название модуля"),
        "type" => "string", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "length" => "30" // длина поля для полей типа string, number
        )
      ),
      "module_text" => array(
        "name" => array("Текст модуля"),
        "type" => "text", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          //"nolang" => "true" // поле одинаково во всех языках, берется значение с индексом [0]
        )
      ),
      "module_isphp" => array(
        "name" => array("Сценарий PHP"),
        "type" => "checkbox", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "default" => array(),
          "nolang" => "true"
          //"length" => "30", // длина поля для полей типа string, number
        )
      ),
      "module_isshow" => array(
        "name" => array("Показывать"),
        "type" => "checkbox", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "default" => array(),
          "nolang" => "true"
          //"length" => "30", // длина поля для полей типа string, number
        )
      ),
      "module_datetime" => array(
        "name" => array("Дата/время изменения"),
        "type" => "datetime", // тип поля string, text, number, checkbox, select
        "params" => array( // параметры поля
          "default" => array(),
          "value" => array("NOW")
          //"editor" => "false", // признак того что для типа text нужен расширенный редактор
          //"length" => "30", // длина поля для полей типа string, number
        )
      ),
      
    ),
    "order" => array("module_order"=>"ASC"), // поля упорядочивания в админке
		"autoreorder" => "true", // автоматическое переупорядочивание при занесении новой записи
  ),

  "session" => array(
    "name" => array("Сессии"),
	  "superadmin" => "true",	// признак объекта который доступен только суперадмину
  	"admin" => array(),
    "fields" => array(
      "session_datetime"=> array(
        "name" => array("Дата/время изменения"),
        "type" => "datetime", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "default" => array(),
          "value" => array("NOW")
        )
      ),
      "session_ln" => array(
        "name" => array("Идентификатор сессии"),
        "type" => "string", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "length" => "30", // длина поля для полей типа string, number
          "nolang" => "true", // поле одинаково во всех языках, берется значение с индексом [0]
          "readonly" => "true",   // неизменяемое значение
      	)
      ),
   		"session_last_query" => array(
        "name" => array("Последняя запрос"),
        "type" => "string", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "length" => "30", // длина поля для полей типа string, number
          "nolang" => "true", // поле одинаково во всех языках, берется значение с индексом [0]
          "readonly" => "true",   // неизменяемое значение
      	)
      ), 
   		"session_isremember" => array(
        "name" => array("Запомнить пользователя"),
        "type" => "checkbox", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "default" => array(),
          "nolang" => "true",
          "readonly" => "true",   // неизменяемое значение
          //"length" => "30", // длина поля для полей типа string, number
        )
      ), 
   		"session_lang" => array(
        "name" => array("Язык"),
        "type" => "string", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
        "params" => array( // параметры поля
          "length" => "30", // длина поля для полей типа string, number
          "nolang" => "true", // поле одинаково во всех языках, берется значение с индексом [0]
          "readonly" => "true",   // неизменяемое значение
      	)
      ), 
//   		"user_id" => array(
//        "name" => array("Пользователь"),
//        "type" => "select", // тип поля string, password, text, number, datetime, checkbox, select, image, sound, video, file
//        "params" => array( // параметры поля
//          "readonly" => "true",   // неизменяемое значение
//      		"length" => "30", // длина поля для полей типа string, number
//          "nolang" => "true", // поле одинаково во всех языках, берется значение с индексом [0]
//          "select" => array( // параметры поля типа select
//            "size" => "1", // size для поля типа select
//            "multiselect" => "false", // возможность множественного выбора для поля типа select
//            "table" => array(
//              "name" => "user", // имя таблицы
//              "field" => "user_id", // имя поля для значений
//              "namefield"=>"user_email", // имя поля для имен
//              "orderfield"=>"user_email", // имя поля упорядочивания
//							"where" => "",		// фильтрация
//      			)
//          )
//        )
//     	),
  
  	),
    "order" => array("session_datetime"=>"DESC"), // поля упорядочивания в админке
		"autoreorder" => "false", // автоматическое переупорядочивание при занесении новой записи
  ),

  "dbquery_all" => array(
    "name" => array("Запрос к БД"),
	  "superadmin" => "true",	// признак объекта который доступен только суперадмину
  	"admin" => array(
      "all" => array(
        "url_template" => "dbquery_all.php",
        "file" => "dbquery_all.php",
        "name" => array("Запрос к БД"),
        )
    ),
    "fields" => array(),
    "order" => array() // поля упорядочивания в админке
  ),

  "mysqldump_all" => array(
    "name" => array("Резервная копия БД"),
	  "superadmin" => "true",	// признак объекта который доступен только суперадмину
  	"admin" => array(
      "all" => array(
        "url_template" => "mysqldump_all.php",
        "file" => "mysqldump_all.php",
        "name" => array("Резервная копия БД"),
        )
    ),
    //"fields" => array(),
    //"order" => array(), // поля упорядочивания в админке
		"autoreorder" => "false", // автоматическое переупорядочивание при занесении новой записи
	),
);

//var_dump($db_forms);
?>