<?
//=============================================================================
// Файл основных настроек
// VN - Virtual Name
// FS - File System

 
//mb_language('uni');
//mb_internal_encoding('UTF-8'); // Устанавливаем кодировку строк
//setlocale(LC_ALL, 'ru_RU.UTF-8'); // Устанавливаем нужную локаль (для дат, денег, запятых и пр.)

/*
if(preg_match("/".preg_quote("mamin.ru")."/",$_SERVER["HTTP_HOST"]))
{
  //-----------------------------------------------------------------------------
  // настройки сайта
  define("VN_SERVER", "http://www.mamin.ru");
  define("VN_DIR", "/");

  //-----------------------------------------------------------------------------
  // настройки административного интерфейса
  define("ADMIN_USER", "admin");
  define("ADMIN_PASSWORD", "VZAPmXH2");
}
elseif(preg_match("/".preg_quote("mamin.infoways.ru")."/",$_SERVER["HTTP_HOST"]))
{
  //-----------------------------------------------------------------------------
  // настройки сайта
  define("VN_SERVER", "http://mamin.infoways.ru");
  define("VN_DIR", "/");

  //-----------------------------------------------------------------------------
  // настройки административного интерфейса
  define("ADMIN_USER", "test");
  define("ADMIN_PASSWORD", "test");
}
elseif(preg_match("/".preg_quote("mamin.local")."/",$_SERVER["HTTP_HOST"]))
{
  //-----------------------------------------------------------------------------
  // настройки сайта
  define("VN_SERVER", "http://mamin.local:8080");
  define("VN_DIR", "/");

  //-----------------------------------------------------------------------------
  // настройки административного интерфейса
  define("ADMIN_USER", "test");
  define("ADMIN_PASSWORD", "test");
}
else
{
	die("WRONG PARAMS!");
}
*/

//-----------------------------------------------------------------------------
// настройки сайта
define("VN_SERVER", "http://qcms.local:8080");
define("VN_DIR", "/");

//-----------------------------------------------------------------------------
// настройки административного интерфейса
define("ADMIN_USER", "test");
define("ADMIN_PASSWORD", "test");

define("VN_INDEX", VN_SERVER . VN_DIR . "index.php");
define("VN_PAGE", VN_SERVER . VN_DIR . "index.php");

define("DIRNAME_ADMIN", "admin");
define("VN_ADMIN", VN_DIR . DIRNAME_ADMIN);
define("VN_ADMIN_INDEX", VN_ADMIN . "/index.php");


define("VN_EDITOR3", VN_ADMIN . "/e/");
define("VN_EDITOR3_SETTINGS", "
			var opts;
			elRTE.prototype.options.panels.qcms1 = [
				'formatblock'
			];
			elRTE.prototype.options.panels.qcms2 = [
				'horizontalrule', 'blockquote', 'div', 'stopfloat', 'nbsp'
			];

			elRTE.prototype.options.toolbars.qcmsToolbar = ['save', 'copypaste', 
				'undoredo', 'style', 'lists', 'alignment', 'indent', 'qcms1',  
				'qcms2', 'links', 'images', 'elfinder', 'tables', 'fullscreen' ];
			                                                			
			
			opts = {
				cssClass : 'el-rte',
				lang     : 'ru',
				width		 : 600,
				height   : 300,
				//toolbar  : 'maxi',
				toolbar  : 'qcmsToolbar',
				allowSource: true,

				fmAllow: true,
        fmOpen : function(callback) {
            $('<div />').elfinder({
                url : '/admin/e/connectors/php/connector.php',
                lang : 'en',
                dialog : { width : 800, modal : true, title : 'Files' }, // open in dialog window
                closeOnEditorCallback : true, // close after file select
                editorCallback : callback     // pass callback to file manager
            })
        },

				cssfiles : ['".VN_EDITOR3."css/elrte-inner.css']
				//cssfiles : ['http://elrte.org/release/elrte/css/elrte-inner.css']
				
			}
		/*
		$().ready(function() {

			//$('#editor').elrte(opts);
		})
		*/
");
define("VN_EDITOR3_SCRIPT", "jQuery('[id]').elrte(opts);");


define("DEFAULT_CHARSET","UTF-8");




// 0 - не показывать ошибки
// 1 - показывть сообщения об ошибках
// ...
// 9 - показывать все, что только возможно
define("ERROR_SHOW", 9);

// site default email
define("EMIAL", "mail@localhost");








//-----------------------------------------------------------------------------
// настройки каталогов

define("DIRNAME_CONFIGURATION", "configuration");               // каталог конфигураций


define("DIRNAME_IMAGES", "images");                   // каталог картинок
define("DIR_IMAGES", VN_DIR . DIRNAME_IMAGES);        // каталог картинок

define("DIRNAME_INCLUDES", "includes");               // каталог инклудов
define("DIR_INCLUDES", VN_DIR . DIRNAME_INCLUDES);    // каталог инклудов

define("DIRNAME_BOXES", "boxes");                     // каталог боксов
define("DIR_BOXES", VN_DIR . DIRNAME_BOXES);          // каталог боксов

define("DIRNAME_CSS", "s");      // каталог css
define("DIR_CSS", VN_SERVER . VN_DIR . DIRNAME_CSS);  // путь к каталогу css
define("FILE_CSS", DIR_CSS. "/style.css");            // основной файл css
define("FILE_CSS_LANG_TEMPLATE", DIR_CSS. "/style_[lang].css");            // основной файл css


define("DIRNAME_TEMPLATES", "templates");             // каталог шаблонов
define("DIRNAME_TEMPLATES_ADMIN", "admin");           // каталог шаблонов
define("DIRNAME_TEMPLATES_ADMIN_VIEWEDIT", ".viewedit"); // каталог шаблонов
define("FILENAME_TEMPLATES_FORM", "form.inc.php");    // каталог шаблонов


//-----------------------------------------------------------------------------
// изображения
define("VIEW_IMAGE", VN_SERVER . VN_DIR . "view_image.php"); // просмотр картинок
define("VN_IMAGE", VN_SERVER . VN_DIR . "image.php"); // страница для просмотра больших картинок
define("VN_PIXEL",  VN_SERVER . VN_DIR . "images/pixel.gif");
define("VN_ERROR_IMAGE", VN_SERVER  . VN_DIR . "images/pixel.gif");

//-----------------------------------------------------------------------------
// настройки видео
define("DIRNAME_VIDEOS", "videos");                           // каталог видео
define("DIR_VIDEOS", VN_DIR . DIRNAME_VIDEOS);                // каталог видео
define("VIEW_VIDEO", VN_SERVER . VN_DIR . "view_video.php");  // просмотр видео
define("VN_ERROR_VIDEO", VN_SERVER . VN_DIR . "/videos/intro.flv");  // ошибка видео
define("VN_VIDEO", VN_SERVER . VN_DIR . "video.php");

//-----------------------------------------------------------------------------
define("LIST_SEPARATOR", "\n");
define("LIST_ITEM_SEPARATOR", "|");


define("LANGUAGE_SPLITTER", "---|LANG|---");

if(!defined("LANGUAGE_DEFAULT"))
{
	define("LANGUAGE_DEFAULT", "RU");
}
$languages = array(); // массив описаний языков
$languages[0] = array("name" => "Рус", "code" => "RU", "num" => 0); // язык по умолчанию
$languages[1] = array("name" => "Eng", "code" => "EN", "num" => 1);



?>
