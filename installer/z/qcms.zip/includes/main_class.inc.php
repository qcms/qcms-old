<?
/**
 * main class CMain 
 * @author Belyaev
 *
 */
class CMain
{
  var $is_header_includes;

  /**
   * administration mode
   * признак того что мы в админке
   * @var boolean
   */
  var $is_admin;
  var $adminuser;
  var $need_session;
  var $need_session_db;
  var $session_last_query;
  var $need_xajax;
  var $need_config;
  var $output_buffering;

  var $body_onload;

  var $modules;

//  var $lang_number;
//  var $lang_code;
//  var $lang_name;

  var $head_scripts;

  /**
   * Entity config
   * @var CEntity
   */
  var $config;

  /**
   * relative path to the root of the site
   * Относительный путь к корню сайта
   * @var string
   */
  var $root;

  /**
   * database object
   * Объект базы данных
   * @var CDatabase
   */
  var $database;
  
  /**
   * callback variables
   * @var array(string)
   */
  var $callback_vars;
  /**
   * callback functions 
   * function function_name() {retrun "value";}
   * @var array(string)
   */
  var $callback_functions; 
  /**
   * callback functions to parse buffer 
   * function function_name($MAIN, &$buffer) { ... modify buffer }
   * @var array(string)
   */
  var $callback_buffer_functions; 
  

  //---------------------------------------------------------------------------
  // конструктор
  function CMain(
    $root = "",
    $params=array(
      "need_session"=>true,
      "need_session_db"=>true,
      "need_xajax"=>true,
      "need_config"=>true,
      "need_database"=>true,
      "output_buffering"=>true,
    	"session_last_query"=>true
    )
  )
  {
    $this->root = $root;
    $this->is_header_includes = false;
    $this->adminuser = false;

    if(!isset($params["need_session"]))
    {
      $params["need_session"] = true;
    }
    if(!isset($params["need_session_db"]))
    {
      $params["need_session_db"] = true;
    }
    if(!isset($params["need_xajax"]))
    {
      $params["need_xajax"] = true;
    }
    if(!isset($params["need_config"]))
    {
      $params["need_config"] = true;
    }
    if(!isset($params["need_database"]))
    {
      $params["need_database"] = true;
    }
    if(!isset($params["output_buffering"]))
    {
      $params["output_buffering"] = true;
    }
    if(!isset($params["session_last_query"]))
    {
      $params["session_last_query"] = true;
    }


    $this->need_session = $params["need_session"];
    $this->need_session_db = $params["need_session_db"];
    $this->need_xajax = $params["need_xajax"];
    $this->need_config = $params["need_config"];
    $this->output_buffering = $params["output_buffering"];
    $this->session_last_query = $params["session_last_query"];
    $this->body_onload = "";
    $this->head_scripts = "";
    $this->is_admin = false;
    $this->callback_vars = array();
    $this->callback_functions = array();
    $this->callback_buffer_functions = array(); 
    
    // необходимые инклуды
    $this->HeaderIncludesRequired();
    
  }


  //---------------------------------------------------------------------------
  // Функция инициализации параметров
	function Init($table=false)
  {
    if($this->need_config)
    {
      $this->config = new CEntity(array("table"=>"config","id"=>1));
    }
    else
    {
      $this->config = null;
    }
    
    $this->adminuser = new CAdminUser();
    if($this->is_admin)
    {
    	$this->AdminAuth($table);
    }
    if($this->output_buffering && function_exists("ob_start"))
    {
    	if($this->is_admin)
    	{
    		$this->AdminContentStart();
    	}
    	else
    	{
    		$this->ContentStart();
    	}
      //ob_start();
    }
  }

  /**
   * 
   */
  function ContentStart()
  {
  	ob_start(array($this, "ContentCallback"));
  }
  
  /**
   * 
   */
  function AdminContentStart()
  {
  	ob_start(array($this, "AdminContentCallback"));
  }
  
  /**
   * @param string $buffer
   * @return string
   */
  function ContentCallback($buffer)
  {
  	//$buffer .= "TEST";
  	if($this->need_config && $this->config && is_a($this->config, "CEntity"))
  	{
  		if($this->config->GetHeader("config_site_isclosed") == "1")
  		{
  			$buffer = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>'.$this->config->GetHeader("config_site_name").'</title>
	<meta name="keywords" content="'.$this->config->GetText("config_site_keywords").'" />
	<meta name="description" content="'.$this->config->GetText("config_site_description").'" />
</head>
<body>
'.$this->config->GetText("config_site_isclosed_message").'
</body>
</html>';
  			//$buffer .= "<pre>".htmlentities($buffer)."</pre>";
  			//return $buffer;
  		}
  	}
  	

  	if(is_array($this->callback_functions) && count($this->callback_functions))
  	{
  		foreach ($this->callback_functions as $function)
  		{
  			if(is_callable($function))
  			{
  				$function_ret = $function();
  				$buffer = preg_replace("/".preg_quote("[___main_callback_function_{$function}___]")."/ims", $function_ret, $buffer);
  			}
  		}
  	}
  	
  	if(is_array($this->callback_vars) && count($this->callback_vars))
  	{
  		foreach ($this->callback_vars as $key => $value)
  		{
  			$buffer = preg_replace("/".preg_quote("[___main_callback_var_{$key}___]")."/ims", $value, $buffer);
  		}
  	}
  	
  	if(is_array($this->callback_buffer_functions) && count($this->callback_buffer_functions))
  	{
  		foreach ($this->callback_buffer_functions as $function)
  		{
  			if(is_callable($function))
  			{
  				$function($this, $buffer);
  			}
  		}
  	}
  	
  	return $buffer;
  }
  
  /**
   * @param string $buffer
   * @return string
   */
  function AdminContentCallback($buffer)
  {
  	$buffer = preg_replace("/".preg_quote("[___main_adminuser_error_messages___]")."/", $this->AdminGetErrors(), $buffer);
  	$buffer = preg_replace("/".preg_quote("[___main_adminuser_messages___]")."/", $this->AdminGetMessages(), $buffer);
  	return $buffer;
  }
    
  
  /**
   * Функция добавления callback переменных
   * @param string $name
   * @param string $value
   */
  function AddCallbackVar($name, $value="")
  {
  	$this->callback_vars[$name] = $value;
  }
  
  /**
   * Функция добавления callback функции
   * @param string $name
   */
  function AddCallbackFunction($name)
  {
  	$this->callback_functions[] = $name;
  }
  
  /**
   * Функция добавления callback функции для буфера
   * @param string $name
   */
  function AddCallbackBufferFunction($name)
  {
  	$this->callback_buffer_functions[] = $name;
  }
  

  /**
   * Функция установки callback переменных
   * @param string $name
   * @param string $value
   */
  function SetCallbackVar($name, $value="")
  {
  	$this->AddCallbackVar($name, $value);
  }

  /**
   * Функция возвращает значение callback переменной
   * @param string $name
   */
  function GetCallbackVar($name)
  {
  	if(isset($this->callback_vars[$name]))
  		return $this->callback_vars[$name];
  	return false;
  }
    
  
  /**
   * Функция удаления callback переменных
   * @param string $name
   */
  function RemoveCallbackVar($name)
  {
  	unset($this->callback_vars[$name]);
  }
  
  /**
   * Функция удаления callback функции
   * @param string $name
   */
  function RemoveCallbackFunction($name)
  {
  	$key = array_search($name, $this->callback_functions);
  	if($key !== FALSE)
  	{
  		unset($this->callback_functions[$key]);
  	}
  }
  
  /**
   * Функция удаления callback функции буфера
   * @param string $name
   */
  function RemoveCallbackBufferFunction($name)
  {
  	$key = array_search($name, $this->callback_buffer_functions);
  	if($key !== FALSE)
  	{
  		unset($this->callback_buffer_functions[$key]);
  	}
  }  
  
  /**
   * Функция вывода callback переменной
   * @param string $name
   */
  function ShowCallbackVar($name, $output=true)
  {
  	$ret = "[___main_callback_var_{$name}___]";
  	
  	if($output)
  	{
  		echo $ret;
  	}
  	else 
  	{
  		return $ret;
  	}
  }
  
  
  /**
   * Функция вывода callback Функции
   * @param string $name
   */
  function ShowCallbackFunction($name, $output=true)
  {
  	$ret = "[___main_callback_function_{$name}___]";
  	
  	if($output)
  	{
  		echo $ret;
  	}
  	else 
  	{
  		return $ret;
  	}
  }
  
  
  
  /**
   * @return string
   */
  function AdminGetErrors()
  {
  	$ret = "";
  	if(is_array($this->adminuser->errors) && count($this->adminuser->errors))
  	{
  		foreach($this->adminuser->errors as $message)
  		{
  			$ret .= '
<div class="error_message">'.$message.'</div>
';  			
  		}
  	}
  	return $ret;
  }
  
  /**
   * @return string
   */
  function AdminGetMessages()
  {
  	$ret = "";
  	if(is_array($this->adminuser->messages) && count($this->adminuser->messages))
  	{
  		foreach($this->adminuser->messages as $message)
  		{
  			$ret .= '
<div class="message">'.$message.'</div>
';  			
  		}
  	}
  	return $ret;
  }
  
  /**
   * Функция выводит сообщения админа (авторизации и запреты)
   */
  function AdminShowMessages()
  {
?>
[___main_adminuser_error_messages___]
[___main_adminuser_messages___]
<?
  }
  
  

  
  
  /**
   * Функция автризации пользователя в админке
   * @param string $table имя таблицы для которой проверить доступ
   * @return bool 
   */
  function AdminAuth($table=false)
  {
  	$ret = false;
  	
	  // заголовки авторизации
	  if ( !isset($_SERVER['PHP_AUTH_USER']) || !isset($_SERVER['PHP_AUTH_PW'])
	  || !$_SERVER['PHP_AUTH_USER'] || !$_SERVER['PHP_AUTH_PW'] ) {
	    header("WWW-Authenticate: Basic realm=\"". VN_SERVER . "\"");
	    header("HTTP/1.0 401 Unauthorized");
	    echo "Need password...\n";
	    exit;
	  }
	  elseif( isset($_SERVER['PHP_AUTH_USER']) && isset($_SERVER['PHP_AUTH_PW']) 
	  && $_SERVER['PHP_AUTH_USER'] && $_SERVER['PHP_AUTH_PW'])
	  {
	    // проверка на админа
	    $this->adminuser = new CAdminUser(array("login"=>$_SERVER['PHP_AUTH_USER'], "password"=>$_SERVER['PHP_AUTH_PW'],));
	    if($this->adminuser->IsAuth($table))
	    {
	    	$ret = true;
	    }
	  }
	  if(!$ret)
	  {
	    // не правильный пароль
	    header("WWW-Authenticate: Basic realm=\"" . VN_SERVER . "\"");
	    header("HTTP/1.0 401 Unauthorized");
	    echo "Wrong password...\n";
	    exit;
	  }
	  
  	return $ret;
  }

  //---------------------------------------------------------------------------
  // Функция возвращает все параметры настроек сайта
  function GetParams()
  {
    global $db_forms;
    if(!isset($db_forms) || !is_array($db_forms))
    {
      return null;
    }
    return $db_forms;
  }

  //---------------------------------------------------------------------------
  // Функция возвращает параметры таблицы
  function GetTableParams($table)
  {
    global $db_forms;
    if(!$table || !isset($db_forms) || !is_array($db_forms) || !isset($db_forms[$table]))
    {
      return null;
    }
    return $db_forms[$table];
  }
  
  
  //---------------------------------------------------------------------------
  // Функция возвращает параметры таблицы
  function GetTableParam($table, $param)
  {
    global $db_forms;
    if(!$table || !isset($db_forms) || !is_array($db_forms) || !isset($db_forms[$table]) || !isset($db_forms[$table][$param]))
    {
      return false;
    }
    return $db_forms[$table][$param];
  }
    

  //---------------------------------------------------------------------------
  // Функция возвращает параметры полей таблицы
  function GetTableFieldsParams($table)
  {
  	$ret = false;
    $table_params = CMain::GetTableParams($table);
    //var_dump($table_params);
    if($table_params && isset($table_params["fields"]) && is_array($table_params["fields"]))
    {
    	$ret = $table_params["fields"];
    }
    unset($table_params);
    return $ret;
  }

  //---------------------------------------------------------------------------
  // Функция возвращает массив полей таблицы  заданного типа
  /**
   * @param string $table - table name
   * @param string $type - type of fields
   * @return array:
   */
  function GetTableFieldsTypeArray($table, $type)
  {
  	$ret = array();
		$table_fields_params = $this->GetTableFieldsParams($table);
		if($type && $table_fields_params && is_array($table_fields_params) && count($table_fields_params))
		{
			foreach($table_fields_params as $key => $value)
			{
				if($value["type"] == $type)
				{
					array_push($ret,$key);
				}
			}
		}
		unset($table_fields_params);
		return $ret;
  }
  
  
  //---------------------------------------------------------------------------
  // Функция возвращает массив полей таблицы  заданных типов
  /**
   * @param string $table - table name
   * @param array $types - types of fields
   * @return array:
   */
  function GetTableFieldsTypesArray($table, $types)
  {
  	$ret = array();
  	foreach ($types as $type)
  	{
  		$ret = array_merge($ret, $this->GetTableFieldsTypeArray($table, $type));
  	}
		return $ret;
  }

  //---------------------------------------------------------------------------
  // Функция возвращает параметры поля таблицы
  function GetTableFieldParams($table, $field)
  {
  	$ret = false;
    $table_fields_params = $this->GetTableFieldsParams($table);
    if($table_fields_params && is_array($table_fields_params) && isset($table_fields_params[$field]))
    {
    	$ret = $table_fields_params[$field];
    }
    unset($table_fields_params);
    return $ret;
  }
  
  //---------------------------------------------------------------------------
  function SetTableFieldParams($table, $field, $params)
  {
  	global $db_forms;
  	if(/*isset($db_forms[$table]["fields"][$field]) &&*/ is_array($params))
  		$db_forms[$table]["fields"][$field] = $params;
  }

  //---------------------------------------------------------------------------
  function UnsetTableField($table, $field)
  {
  	global $db_forms;
  	if(isset($db_forms[$table]["fields"][$field]))
  		unset($db_forms[$table]["fields"][$field]);
  }
  
  
  //---------------------------------------------------------------------------
  function AddTableFieldParams($table, $field, $params, $after=false)
  {
  	global $db_forms;
  	if(/*isset($db_forms[$table]["fields"][$field]) &&*/ is_array($params))
  	{
  		
  		if($after && (isset($db_forms[$table]["fields"][$after]) || $after=="FIRST"))
  		{
  			// добавление после заданного объекта
  			$fields = $db_forms[$table]["fields"];
  			$fields_new = array();
  			
  			if($after=="FIRST")
  			{
  					$fields_new[$field] = $params;
  			}
  			
  			foreach ($fields as $key=>$value)
  			{
  				if($after!="FIRST" && $key == $after)
  				{
  					$fields_new[$key] = $value;
  					$fields_new[$field] = $params;
  				}
  				else
  				{
  					$fields_new[$key] = $value;
  				}
  			}
  			$db_forms[$table]["fields"] = $fields_new;
  			unset($fields_new);
  			unset($fields);
  		}
  		else
  		{
  			// простое добавление
  			$db_forms[$table]["fields"][$field] = $params;
  		}
  	}
  }  
  //---------------------------------------------------------------------------
  // Функция возвращает заданный параметр поля таблицы
  function GetTableFieldParam($table, $field, $param)
  {
  	return CMain::GetTableFieldParamEx($table, $field, $param);
  }
  
  //---------------------------------------------------------------------------
  // Функция возвращает заданный параметр поля таблицы
  function GetTableFieldParamsParam($table, $field, $param)
  {
  	return CMain::GetTableFieldParamEx($table, $field, "params", $param);
  }
  
  
  //---------------------------------------------------------------------------
  // Функция возвращает заданный параметр поля таблицы
  function GetTableFieldParamEx($table, $field, $param, $param1=false, $param2=false, $param3=false)
  {
  	$ret = false;

  	$table_fields_params = CMain::GetTableFieldsParams($table);

  	if($table_fields_params && is_array($table_fields_params) && isset($table_fields_params[$field][$param]))
  	{
	  	if($param3 && isset($table_fields_params[$field][$param][$param1][$param2][$param3]))
	    	$ret = $table_fields_params[$field][$param][$param1][$param2][$param3];
	    elseif(!$param3 && $param2 && isset($table_fields_params[$field][$param][$param1][$param2]))
		    $ret = $table_fields_params[$field][$param][$param1][$param2];
	    elseif(!$param2 && !$param3 && $param1 && isset($table_fields_params[$field][$param][$param1]))
				$ret = $table_fields_params[$field][$param][$param1];
			elseif(!$param1 && !$param2 && !$param3)
		    $ret = $table_fields_params[$field][$param];
  	}
  	
    unset($table_fields_params);  	
  	
  	return $ret;
  }
  
  //---------------------------------------------------------------------------
  // Функция устанавливает заданный параметр поля таблицы
  function SetTableFieldParam($table, $field, $param, $value=false)
  {
		$this->SetTableFieldParamEx($table, $field, $param, false, false, false, $value);
  }
    
  //---------------------------------------------------------------------------
  // Функция устанавливает заданный параметр поля таблицы
  function SetTableFieldParamsParam($table, $field, $param, $value=false)
  {
		$this->SetTableFieldParamEx($table, $field, "params", $param, false, false, $value);
		//global $db_forms; var_dump($db_forms[$table]["fields"][$field]); exit;
  }
  
  
  //---------------------------------------------------------------------------
  // Функция устанавливает заданный параметр поля таблицы
  function SetTableFieldParamEx($table, $field, $param, $param1=false, $param2=false, $param3=false, $value=false)
  {
  	global $db_forms;

  	if(isset($db_forms[$table]["fields"][$field]))
  	{
  		if($value)
  		{
		  	if($param3 && isset($db_forms[$table]["fields"][$field][$param][$param1][$param2]))
		    	$db_forms[$table]["fields"][$field][$param][$param1][$param2][$param3] = $value; 
		    elseif(!$param3 && $param2 && isset($db_forms[$table]["fields"][$field][$param][$param1]))
		    	$db_forms[$table]["fields"][$field][$param][$param1][$param2] = $value; 
		    elseif(!$param2 && !$param3 && $param1 && isset($db_forms[$table]["fields"][$field][$param]))
		    	$db_forms[$table]["fields"][$field][$param][$param1] = $value; 
		    elseif(!$param1 && !$param2 && !$param3)
			    $db_forms[$table]["fields"][$field][$param] = $value;
  		}
  		else
  		{
		  	if($param3 && isset($db_forms[$table]["fields"][$field][$param][$param1][$param2]))
		    	unset($db_forms[$table]["fields"][$field][$param][$param1][$param2][$param3]); 
		    elseif(!$param3 && $param2 && isset($db_forms[$table]["fields"][$field][$param][$param1]))
		    	unset($db_forms[$table]["fields"][$field][$param][$param1][$param2]); 
		    elseif(!$param2 && !$param3 && $param1 && isset($db_forms[$table]["fields"][$field][$param]))
		    	unset($db_forms[$table]["fields"][$field][$param][$param1]); 
		    elseif(!$param1 && !$param2 && !$param3)
		    	unset($db_forms[$table]["fields"][$field][$param]); 
  		}
  	}
  }  
  
  //---------------------------------------------------------------------------
  // Функция проверки того что загружен заголовок базовой функциональности сайта
  function IsHeaderIncludes()
  {
    return $this->is_header_includes;
  }

  
  

  //---------------------------------------------------------------------------
  // Функция возвращает сущность для заданного языка
  function GetEntityLang(
  	$params=array(
  		"table"=>"", 
  		"id"=>"", 
  		"index_suffix"=>null, 
  		"lang"=>""
  	)
  )
  {
  	global $languages;
  	// проверим параметры
  	if(!isset($params["table"]) || !$params["table"]
  	|| !isset($params["id"]) || !$params["id"]
  	|| !isset($params["lang"]) || !$params["lang"]
  	)
  	{
  		echo "GetEntityLang: wrong params!";
  		if(ERROR_SHOW == 9)
  		{
  			var_dump($params);
  			debug_print_backtrace();
  		}
  		exit;
  	}
  	
  	// проверим язык
  	/*
  	if(!in_array($params["lang"], $languages))
  	{
  		echo "GetEntityParamLang: wrong lang param!";
  		if(ERROR_SHOW == 9)
  		{
  			debug_print_backtrace();
  		}
  		exit;
  	}
		*/
  	
  	$ret = null;
  	$lang_old = $_SESSION["lang"]; // сохраним язык
  	$_SESSION["lang"] = $params["lang"];
  	unset($params["lang"]);
  	$entity = new CEntity($params);
  	
  	if($entity->identity)
  	{
  		$ret = $entity;
  	}
  	$_SESSION["lang"] = $lang_old; // вернем язык
  	return $ret;
  }
  
  //---------------------------------------------------------------------------
  // Функция возвращает поле для заданного языка
  function GetEntityFieldLang(
  	$params=array(
  		"table"=>"", 
  		"field"=>"", 
  		"id"=>"", 
  		"index_suffix"=>null, 
  		"lang"=>""
  	)
  )
  {
  	global $languages;
  	// проверим параметры
  	if(!isset($params["table"]) || !$params["table"]
  	|| !isset($params["field"]) || !$params["field"]
  	|| !isset($params["id"]) || !$params["id"]
  	|| !isset($params["lang"]) || !$params["lang"]
  	)
  	{
  		echo "GetEntityParamLang: wrong params!";
  		if(ERROR_SHOW == 9)
  		{
  			var_dump($params);
  			debug_print_backtrace();
  		}
  		exit;
  	}

  	$ret = null;
  	$entity = $this->GetEntityLang($params);
  	if($entity && $entity->identity)
  	{
  		$ret = $entity->GetField($params["field"]);
  	}
  	
  	return $ret;
  	// проверим язык
  	/*
  	if(!in_array($params["lang"], $languages))
  	{
  		echo "GetEntityParamLang: wrong lang param!";
  		if(ERROR_SHOW == 9)
  		{
  			debug_print_backtrace();
  		}
  		exit;
  	}
		*/
  	
  	/*
  	
  	$ret = null;
  	$lang_old = $_SESSION["lang"]; // сохраним язык
  	$_SESSION["lang"] = $params["lang"];
  	if(isset($params["index_suffix"]) && $params["index_suffix"])
  	{
  		$entity = new CEntity(
  			array(
  				"table"=>$params["table"], 
  				"id"=>$params["id"], 
  				"index_suffix"=>$params["index_suffix"]
  			)
  		);
  	}
  	else
  	{
  		$entity = new CEntity(
  			array(
  				"table"=>$params["table"], 
  				"id"=>$params["id"]
  			)
  		);
  	}
  	if($entity->identity)
  	{
  		$ret = $entity->GetField($params["field"]);
  	}
  	$_SESSION["lang"] = $lang_old; // вернем язык
  	return $ret;
		*/
  }

  //---------------------------------------------------------------------------
  // Функция загрузки обязательных инклудов сайта
  function HeaderIncludesRequired()
  {
    // действительно необходимые конфигурации
    include_once($this->root . DIRNAME_CONFIGURATION. "/configuration.inc.php");
//    if(file_exists($this->root . DIRNAME_CONFIGURATION . "/configuration.database.inc.php"))
//    	include_once($this->root . DIRNAME_CONFIGURATION . "/configuration.database.inc.php");
    if(file_exists($this->root . DIRNAME_CONFIGURATION . "/configuration.entity.inc.php"))
	    include_once($this->root . DIRNAME_CONFIGURATION . "/configuration.entity.inc.php");

    // обязательно нужные функции
    if(file_exists($this->root . DIRNAME_INCLUDES . "/functions.inc.php"))
      include_once($this->root . DIRNAME_INCLUDES . "/functions.inc.php");
    
      
    // обязательно нужные классы (база данных, сущность, изображение, навигация)
    if(file_exists($this->root . DIRNAME_INCLUDES . "/database_class.inc.php"))
      include_once($this->root . DIRNAME_INCLUDES . "/database_class.inc.php");
    if(file_exists($this->root . DIRNAME_INCLUDES . "/entity_class.inc.php"))
      include_once($this->root . DIRNAME_INCLUDES . "/entity_class.inc.php");
    if(file_exists($this->root . DIRNAME_INCLUDES . "/navigation_class.inc.php"))
      include_once($this->root . DIRNAME_INCLUDES . "/navigation_class.inc.php");
    if(file_exists($this->root . DIRNAME_INCLUDES . "/configuration.image.inc.php"))
      include_once($this->root . DIRNAME_INCLUDES . "/configuration.image.inc.php");
		if(file_exists($this->root . DIRNAME_INCLUDES . "/image_class.inc.php"))
      include_once($this->root . DIRNAME_INCLUDES . "/image_class.inc.php");
      
    if(file_exists($this->root . DIRNAME_INCLUDES . "/user_class.inc.php"))
      include_once($this->root . DIRNAME_INCLUDES . "/user_class.inc.php");
  }


  //---------------------------------------------------------------------------
  // Функция загрузки инклудов сайта
  function HeaderIncludes()
  {
    $this->HeaderIncludesRequired();

    // не обязательные классы (звук, видео и т.п.)
    if(file_exists($this->root . DIRNAME_INCLUDES . "/configuration.sound.inc.php"))
      include_once($this->root . DIRNAME_INCLUDES . "/configuration.sound.inc.php");
    if(file_exists($this->root . DIRNAME_INCLUDES . "/sound_class.inc.php"))
      include_once($this->root . DIRNAME_INCLUDES . "/sound_class.inc.php");
      
    if(file_exists($this->root . DIRNAME_INCLUDES . "/configuration.video.inc.php"))
      include_once($this->root . DIRNAME_INCLUDES . "/configuration.video.inc.php");
    if(file_exists($this->root . DIRNAME_INCLUDES . "/video_class.inc.php"))
      include_once($this->root . DIRNAME_INCLUDES . "/video_class.inc.php");
      
    if(file_exists($this->root . DIRNAME_INCLUDES . "/configuration.file.inc.php"))
      include_once($this->root . DIRNAME_INCLUDES . "/configuration.file.inc.php");
    if(file_exists($this->root . DIRNAME_INCLUDES . "/file_class.inc.php"))
      include_once($this->root . DIRNAME_INCLUDES . "/file_class.inc.php");

		if(file_exists($this->root . DIRNAME_INCLUDES . "/configuration.user.inc.php"))
      include_once($this->root . DIRNAME_INCLUDES . "/configuration.user.inc.php");
		if(file_exists($this->root . DIRNAME_INCLUDES . "/user_class.inc.php"))
      include_once($this->root . DIRNAME_INCLUDES . "/user_class.inc.php");
      
    if($this->need_session)
    {
      if(file_exists($this->root . DIRNAME_INCLUDES . "/configuration.session.inc.php"))
        include_once($this->root . DIRNAME_INCLUDES . "/configuration.session.inc.php");
      if(file_exists($this->root . DIRNAME_INCLUDES . "/session.inc.php"))
        include_once($this->root . DIRNAME_INCLUDES . "/session.inc.php");
    }
    if($this->need_xajax)
    {
      if(file_exists($this->root . DIRNAME_INCLUDES . "/xajax.inc.php"))
        include_once($this->root . DIRNAME_INCLUDES . "/xajax.inc.php");
    }


    $this->is_header_includes = true;
  }


  //---------------------------------------------------------------------------
  // Функция добавляет событие body.OnLoad
  function SetBodyOnLoad($body_onload)
  {
    if($this->body_onload)
    {
      if($body_onload)
        $this->body_onload .= "; " . $body_onload;
    }
    else
    {
      $this->body_onload = $body_onload;
    }
    return true;
  }

  //---------------------------------------------------------------------------
  // Функция возвращает событие body.OnLoad
  function GetBodyOnLoad()
  {
    return $this->body_onload;
  }


  //---------------------------------------------------------------------------
  // Функция инклудит статичный файл
  function IncludeFile($file, $admin=false, $once=false)
  {
    //global $root;
    $filename = $this->root;
    if($admin)
    {
      $filename .= DIRNAME_ADMIN . "/";
    }
    $filename .= $file;
    //var_dump($filename);
    if(file_exists($filename))
    {
    	if($once)
    	{
      	include_once($filename);
    	}
    	else 
    	{
      	include($filename);
    	}
    }
  }


  //---------------------------------------------------------------------------
  // Функция инклудит статичный файл из каталога boxes
  function IncludeModule($module_file, $admin=false, $once=false)
  {
		$this->IncludeModuleEx($this->root, $module_file, $admin, $once);
  }
  
  //---------------------------------------------------------------------------
  // Функция проверяет что модуль существует
  function CheckModuleExists($module_file, $admin=false)
  {
  	return $this->CheckModuleExistsEx($this->root, $module_file, $admin);
  }

  //---------------------------------------------------------------------------
  // Функция инклудит статичный файл из каталога boxes
  function IncludeModuleEx($root, $module_file, $admin=false, $once=false)
  {
    //global $root;
    $filename = $root;
    if($admin)
    {
      $filename .= DIRNAME_ADMIN . "/";
    }
    $filename .= DIRNAME_BOXES."/".$module_file;
    //var_dump($filename);
    if(file_exists($filename))
    {
    	if($once)
    	{
				include_once($filename);
    	}
    	else 
    	{
				include($filename);
    	}
    }
  }
  
  //---------------------------------------------------------------------------
  // Функция проверяет что модуль существует
  function CheckModuleExistsEx($root, $module_file, $admin=false)
  {
    $filename = $root;
    if($admin)
    {
      $filename .= DIRNAME_ADMIN . "/";
    }
    $filename .= DIRNAME_BOXES."/".$module_file;
    //var_dump($filename);
    if(file_exists($filename))
    {
    	return true;
    }
    return false;
  }
  
  
  //---------------------------------------------------------------------------
  // Функция отображения модуля по его мнемокоду
  function ShowModule($module_ln)
  {
    $module = new CEntityEx(
      array(           // массив параметров базы данных объекта
        "table"=>"module",                // таблица объекта
        "id"=>$module_ln,                  // идентификатор объекта в БД
        "index_suffix"=>"ln",        // суфикс для индексного поля
        "template"=>"[text:module_text]",          // шаблон отображения объекта
      )
    );

    if($module->identity && $module->headers["module_isshow"] == "1")
    {
        if(isset($module->headers["module_link"])
        && $module->headers["module_link"]
        && file_exists($this->root . "boxes/" . $module->headers["module_link"])
        )
        {
            include($this->root . "boxes/" . $module->headers["module_link"]);
        }
        else
        {
            if($module->headers["module_isphp"] == "1")
            {
              $module->ViewEx(array("output"=>"false"));
              eval($module->view);
            }
            else
            {
              $module->ViewEx();
            }
        }
    }
    return true;
  }

  //---------------------------------------------------------------------------
  // Функция возвращает контент модуля по его мнемокоду
  function GetModuleContent($module_ln)
  {
    $module = new CEntityClass(
      array(           // массив параметров базы данных объекта
        "table"=>"module",                // таблица объекта
        "id"=>$module_ln,                  // идентификатор объекта в БД
        "dates_keys"=>array("module_datetime"),      // поля где хранятся дата, дата время
        "headers_keys"=>array("module_ln", "module_link", "module_name","module_isshow"),    // поля заголовков
        "texts_keys"=>array("module_text"),      // текстовые поля
        "images_keys"=>array(),     // поля изображений
        "sound_keys"=>array(),      // поля звуков
        "video_keys"=>array(),      // поля видео
        "files_keys"=>array(),      // поля бинарных файлов
        "nolang_keys"=>array("module_ln", "module_link", "module_isshow"),     // поля которые не участвуют в поддержке языков
        "index_suffix"=>"ln",        // суфикс для индексного поля
        "template"=>"[text:module_text]",          // шаблон отображения объекта
      )
    );

    if($module->entity_id && $module->headers["module_isshow"] == "1")
    {
        if(isset($module->headers["module_link"])
        && $module->headers["module_link"]
        && file_exists($this->root . "boxes/" . $module->headers["module_link"])
        )
        {
            return($this->root . "boxes/" . $module->headers["module_link"]);
        }
        else
        {
        	$module->view_entity(false);
          return $module->view;
        }
    }
    return "";
  }
  


  //---------------------------------------------------------------------------
  // функция возвращает текстовый контент для текущего языка
  function GetCurrentValueLang($value)
  {
    return CMain::GetValueLang($value, CMain::GetLangCode());
  }

  //---------------------------------------------------------------------------
  // функция возвращает текстовый контент строго для текущего языка
  function GetCurrentStrictValueLang($value)
  {
    return CMain::GetStrictValueLang($value, CMain::GetLangCode());
  }
  

  //---------------------------------------------------------------------------
  function SetArrayLang(&$arr, $new_value, $lang_code)
  {
  	$arr[CMain::GetLangNumber($lang_code)] = $new_value;
  }
  
  //---------------------------------------------------------------------------
  // функция устанавливает текстовый контент для данного языка
  // возвращает результат
  function SetValueLang(&$value,$new_value,$lang_code)
  {
    global $languages;

    // количество языков
    $languages_count = count($languages);
    if(!$languages_count || $languages_count <= 0)
    {
      return false;
    }

    $lang_num = CMain::GetLangNumber($lang_code);
    $value_new = "";
    $values = preg_split("/" . preg_quote(LANGUAGE_SPLITTER) . "/",$value);
    $values_count = count($values);
    for($i=0;$i<$languages_count;$i++)
    {
      if($i > 0)
      {
        $value_new .= LANGUAGE_SPLITTER;
      }
      if($i == $lang_num)
      {
        $value_new .= $new_value;
        continue;
      }
      if($i < $values_count && isset($values[$i]))
      {
        // если есть старое значение то следует установить его
        $value_new .= $values[$i];
      }
      else 
      {
      	$value_new .= "";
      	//$value_new .= "_";
      }
    }

    $value = $value_new; // вернем через параметры результат
		//error_log(print_r($value,true));

    return true;
  }

  
  //---------------------------------------------------------------------------
  // функция устанавливает текстовый контент для текущего языка
  function SetCurrentValueLang(&$value,$new_value)
  {
		return CMain::SetValueLang($value, $new_value, $_SESSION["lang"]);
  }

  //---------------------------------------------------------------------------
  // функция устанавливает значение в массив для текущего языка
  function SetCurrentArrayLang(&$arr,$new_value)
  {
  	CMain::SetArrayLang($arr, $new_value, $_SESSION["lang"]);
  	if($return)
  	{
  		return $arr;
  	}
  }
  
  
  /**
   * функция устанавливает значение в массив для текущего языка
   * @param array $arr
   * @param string $new_value
   * @return array
   */
  function SetCurrentArrayLangRet($arr,$new_value)
  {
  	CMain::SetArrayLang($arr, $new_value, $_SESSION["lang"]);
  	return $arr;
  }  
  
  
  /**
   * Функция возвращает языковой массив заполненый заданным значение $value
   * @param string $value
   * @return multitype
   */
  function NewArrayLang($value="")
  {
  	$ret = array();
  	global $languages;
  	foreach ($languages as $key=>$val)
  	{
  		$ret[$key] = $value;
  	}
  	return $ret;
  }
  

  //---------------------------------------------------------------------------
  // функция возвращает текстовый контент для заданного языка
  function GetValueLang($value,$lang_code)
  {
    global $languages;

    // количество языков
    $languages_count = count($languages);
    if(!$languages_count || $languages_count <= 0)
    {
      return $value;
    }

    $lang_num = CMain::GetLangNumber($lang_code);
    if(!preg_match("/" . preg_quote(LANGUAGE_SPLITTER) ."/", $value))
    {
      // нет разделителя вернем $value целиком
      return $value;
    }

    $values = preg_split("/" . preg_quote(LANGUAGE_SPLITTER) . "/",$value);
    if($lang_num < count($values) && $values[$lang_num])
    {
      return $values[$lang_num];
    }
    else
    {
      return $values[0];
    }

  }

  //---------------------------------------------------------------------------
  // функция возвращает текстовый контент строго для заданного языка
  // если нет контента возвращает пустую строку
  function GetStrictValueLang($value,$lang_code)
  {
    global $languages;

    // количество языков
    $languages_count = count($languages);
    if(!$languages_count || $languages_count <= 0)
    {
      return $value;
    }

    $lang_num = CMain::GetLangNumber($lang_code);
    if(!preg_match("/" . preg_quote(LANGUAGE_SPLITTER) ."/", $value))
    {
      // нет разделителя вернем $value целиком
      return $value;
    }

    $values = preg_split("/" . preg_quote(LANGUAGE_SPLITTER) . "/",$value);
    if($lang_num < count($values) && $values[$lang_num])
    {
      return $values[$lang_num];
    }
    else
    {
      return "";
    }

  }  
  
  //---------------------------------------------------------------------------
  // функция возвращает текстовый контент для текущего языка из массива
  function GetCurrentArrayLang($array)
  {
    return CMain::GetArrayLang($array, CMain::GetLangCode());
  }

  //---------------------------------------------------------------------------
  // функция возвращает текстовый контент для заданного языка из массива
  function GetArrayLang($array,$lang_code)
  {
    global $languages;

    if(!is_array($array))
    {
      return "";
    }

    // количество языков
    $languages_count = count($languages);
    if(!$languages_count || $languages_count <= 0)
    {
      return $array[0];
    }

    $lang_num = CMain::GetLangNumber($lang_code);

    if($lang_num >= count($array))
    {
      return $array[0];
    }
    return $array[$lang_num];

    /*
    if(!preg_match("/" . preg_quote(LANGUAGE_SPLITTER) ."/", $value))
    {
      // нет разделителя вернем $value целиком
      return $value;
    }

    $values = preg_split("/" . preg_quote(LANGUAGE_SPLITTER) . "/",$value);
    if($lang_num < count($values) && $values[$lang_num])
    {
      return $values[$lang_num];
    }
    else
    {
      return $values[0];
    }
    */

  }


  //---------------------------------------------------------------------------
  // функция возвращает в виде массива строковую величину с разделителями
  function GetArrayLangFromValue($value)
  {
    global $languages;

    $ret = array();
    
    if(!$value)
    {
      return $ret;
    }

    // количество языков
    $languages_count = count($languages);
    if(!$languages_count || $languages_count <= 0)
    {
      return $ret;
    }

    foreach ($languages as $l)
    {
    	$ret[$l["num"]] = CMain::GetStrictValueLang($value, $l["code"]);
    }
    
    return $ret;
  }
  
  /**
   * Функция возвращает строки собранную из языкового массива 
   * @param unknown_type $array
   * @return string
   */
  function GetStringFromArrayLang($array)
  {
  	$ret = "";
  	$ret = implode(LANGUAGE_SPLITTER, $array);
  	return $ret;
  }
  
  //---------------------------------------------------------------------------
  // функция возвращает порядковый номер для языка
  function GetLangNumber($lang_code)
  {
    global $languages;
    if(!$lang_code || !is_array($languages))
    {
      return 0;
    }
    foreach($languages as $language)
    {
      if($language["code"] == $lang_code)
      {
        return $language["num"];
      }
    }

    return 0;
  }


  //-----------------------------------------------------------------------------
  // Функция возвращает код текущего языка
  function GetLangCode()
  {
    if(session_id() && isset($_SESSION["lang"]))
    {
      return $_SESSION["lang"];
    }
    return LANGUAGE_DEFAULT;
  }

  
  //-----------------------------------------------------------------------------
  // Функция возвращает имя текущего языка
  function GetLangName()
  {
  	global $languages;
    if(session_id() && isset($_SESSION["lang"]) && isset($languages) && is_array($languages))
    {
	  	$num = CMain::GetLangNumber(CMain::GetLangCode());
	  	if(isset($languages[$num]))
	  	{
	  		return $languages[$num]["name"];
	  	}
    }
    return "";
  }
  


  //---------------------------------------------------------------------------
  // Функция показа ошибки при вызове die
  // в зависимости от текущих параметров отображения
  function ErrorShow($params = array())
  {
    $params_default = array(
      "message" => null,
      "query" => null
    );

    if(!isset($params["message"]))
    {
      $params["message"] = $params_default["message"];
    }
    if(!isset($params["query"]))
    {
      $params["query"] = $params_default["query"];
    }

    //$message = "Ошибка!";

    $ret = "";
    if(ERROR_SHOW <= 0)
      return $ret;

    if($params["message"])
    {
    $ret .= $params["message"] . "
  ";
    }

    if(ERROR_SHOW <= 1)
      return;

  //  $arr = error_get_last();
  //  $ret .= "type = " . $arr["type"] . "
  //";
  //  $ret .= "message = " . $arr["message"] . "
  //";
  //  $ret .= "file = " . $arr["file"] . "
  //";
  //  $ret .= "line = " . $arr["line"] . "
  //";
  //
    if(ERROR_SHOW <= 2)
      return $ret;

    if($params["query"])
    {
      $ret .= mysql_errno() . ": " . mysql_error(). "
  ";
    }

    if(ERROR_SHOW <= 3)
      return $ret;

    if($params["query"])
    {
      $ret .= $params["query"] . "
  ";
    }

    if(ERROR_SHOW <= 4)
      return $ret;

    if(ERROR_SHOW == 9)
    {
      //error_log($ret);

      $ret .= "
        " . print_r(debug_backtrace(), true);
    }
  //  debug_print_backtrace();

    return $ret;

  }


  //---------------------------------------------------------------------------
  // Функция возвращает путь к файлу шаблона
  // параметры:
  //    $template - имя шаблона
  //    $element - элемент шаблона
  //    $is_admin - элемент административного интерфейса
  function GetTemplatePath($template, $element, $element_item, $is_admin=false)
  {
    $ret = "";

    $ret .= $this->root . DIRNAME_TEMPLATES ."/". $template;
    if($is_admin)
    {
      $ret .= "/" . DIRNAME_TEMPLATES_ADMIN;
    }
    $ret .= "/" . $element . "/" . $element_item .".inc.php";

    return $ret;
  }


  //---------------------------------------------------------------------------
  // Функция замены параметров шаблона значениями переменных из GET запроса
  function ReplaceTemplateGetParams($template, $params=array(), $use_globals=true, $use_get=false)
  {
    $ret = $template;
    $matches = null;
    if(preg_match_all("/\\[\\w+\\]/", $template, $matches) && $matches)
    {
      //var_dump($matches[0]);
      foreach($matches[0] as $value)
      {
        //var_dump($value);
        $key = substr($value, 1, -1);

        if(isset($params[$key]))
        {
          $ret = str_replace($value, $params[$key], $ret);
        }
        elseif($use_get && isset($_GET[$key]))
        {
          $ret = str_replace($value, $_GET[$key], $ret);
        }
        elseif($use_globals && isset($GLOBALS[$key]))
        {
          $ret = str_replace($value, $GLOBALS[$key], $ret);
        }
      }
      //var_dump($matches);
    }
    return $ret;

  }

  //---------------------------------------------------------------------------
  // Функция проверки того что выполнен запрос на Save
  function CheckPost($action_name="action", $action_value="edit")
  {
      if(isset($_GET[$action_name]) && $_GET[$action_name] === $action_value
      && isset($_POST) && is_array($_POST) && count($_POST))
      {
        return true;
      }

      return false;
  }

  
  //---------------------------------------------------------------------------
  // Функция проверки значения в POST запросе
  function CheckPostValue($name, $value)
  {
  	if(isset($_POST[$name]) && $_POST[$name] == $value)
  		return true;
  	return false;
  }
  
  
  //---------------------------------------------------------------------------
  // Функция проверки того что в POST запросе есть необходимый параметр
  function CheckPostExists($_name="action")
  {
      if(isset($_POST) && isset($_POST[$_name]) && $_POST[$_name])
      {
        return true;
      }

      return false;
  }
  //---------------------------------------------------------------------------
  // Функция проверки того что выполнен запрос на Save
  function CheckGet($action_name="action", $action_value="edit")
  {
      if(isset($_GET) && isset($_GET[$action_name]) && $_GET[$action_name] === $action_value)
      {
        return true;
      }

      return false;
  }


  //---------------------------------------------------------------------------
  // Функция проверки того что в запросе есть необходимый параметр
  function CheckGetExists($_name="action")
  {
      if(isset($_GET) && isset($_GET[$_name]) && $_GET[$_name])
      {
        return true;
      }

      return false;
  }


  //---------------------------------------------------------------------------
  // Функция возвращает имя файла страницы по ее коду в административном интерфейсе
  function GetAdminPageFile($table, $key)
  {
  	$ret = "";
    $tableParams = $this->GetTableParams($table);
    if(isset($tableParams["admin"][$key]["file"]))
    {
      $ret = $tableParams["admin"][$key]["file"];
    }
    unset($tableParams);
    return $ret;
  }
  
  //---------------------------------------------------------------------------
  // Функция возвращает имя файла страницы по ее коду в административном интерфейсе
  function GetAdminPageUrl($table, $key, $params=false, $use_globals=false, $use_get=false)
  {
  	$ret = "";
    $tableParams = $this->GetTableParams($table);
    if(isset($tableParams["admin"][$key]["url_template"]))
    {
      $ret = $tableParams["admin"][$key]["url_template"];
      //var_dump($ret);
      if($params || $use_globals || $use_get)
      	$ret = $this->ReplaceTemplateGetParams($ret, $params, $use_globals, $use_get);
    }
    unset($tableParams);
    return $ret;
  }
  
  //---------------------------------------------------------------------------
  // Функция возвращает имя страницы по ее коду в административном интерфейсе
  function GetAdminPageName($table, $key)
  {
  	$ret = "";
    $tableParams = $this->GetTableParams($table);
    if(isset($tableParams["admin"][$key]["name"]))
    {
      $ret = $this->GetCurrentArrayLang($tableParams["admin"][$key]["name"]);
    }
    unset($tableParams);
    return $ret;
  }
  //---------------------------------------------------------------------------
  // Функция возвращает имя объекта по его мнемокоду
  function GetAdminEntityName($table)
  {
  	$ret = "";
    $tableParams = $this->GetTableParams($table);
    //var_dump($tableParams["name"]);
  	$ret = $this->GetCurrentArrayLang($tableParams["name"]);
  	unset($tableParams); 
  	return $ret;
  }
  
  //---------------------------------------------------------------------------
  // Функция возвращает имя поля таблицы
  function GetAdminEntityFieldName($table, $field)
  {
  	$ret = "";
    $tableFieldParams = $this->GetTableFieldParams($table, $field);
    //var_dump($tableParams["name"]);
  	$ret = $this->GetCurrentArrayLang($tableFieldParams["name"]); 
  	unset($tableFieldParams);
  	return $ret;
  }
  
  
  //---------------------------------------------------------------------------
  // Функция вовзвращает список сущностей выбранных для заданных действий админки
  // действия админки $arAdminDo = array("all", "edit", "list"), пустой массив  - все
  function GetAdminEntities($arAdminDo = false, $bCheckFieldsExists=false, $bSuperadmin=false)
  {
  	$ret = array();
  	
  	$params = $this->GetParams();
  	foreach($params as $table => $tableParams)
  	{
  		$bNeed = false;
  		if(is_array($arAdminDo) && is_array($tableParams["admin"]))
  		{
  			foreach ($arAdminDo as $do)
  			{
  				if(array_key_exists($do, $tableParams["admin"]))
  				{
  					$bNeed = true;
  					break;
  				}
  			}
  		}
  		else
  		{
  			$bNeed = true;
  		}
  		if($bCheckFieldsExists && (!is_array($tableParams["fields"]) || !count($tableParams["fields"])))
  			$bNeed = false;
  		
  		if(!$bSuperadmin && isset($tableParams["superadmin"]) && $tableParams["superadmin"]=="true")
  			$bNeed = false;
  			
  		if($bNeed)
  			$ret[] = $table;
  	}
  	unset($params);
  	
  	return $ret;
  }
  
  //---------------------------------------------------------------------------
  // Функция выполняет дополнительные действия для заданной таблице в админке
  function AdminActions($table)
  {
    if(!$this->is_admin)
    {
      // если не режим админки то просто выходим
      return;
    }

    $tableParams = $this->GetTableParams($table);
    if(isset($tableParams["admin"]["actions"]["file"]))
    {
      $filename = "";
      if(file_exists($filename))
      {
        include($filename);
      }
    }
  }
  
  //---------------------------------------------------------------------------
  function GetSessionLastQuery()
  {
  	if(isset($_SESSION["session_last_query"]))
  		return $_SESSION["session_last_query"];
  	return "";
  }
  
  
  /**
   * Include entity params
   * Подключает параметры заданной сущности
   * @param string $entity_name
   */
  function IncludeEntity($entity_name)
  {
  	global $entity, $db_forms;
  	
  	if(!strlen($entity_name))
  	{
  		return;
  	}
  	
  	$entity = false;
  	
  	if(!is_array($db_forms))
  	{
  		$db_forms = array();
  	}
  	
  	if(file_exists($this->root."configuration/system/entities/{$entity_name}/entity.inc.php"))
  	{
  		include($this->root."configuration/system/entities/{$entity_name}/entity.inc.php");
  		if(isset($entity) && is_array($entity))
  		{
  			$db_forms = array_merge($db_forms, $entity);
  		}
  	}
  	elseif(file_exists($this->root."configuration/entities/{$entity_name}/entity.inc.php"))
  	{
  		include($this->root."configuration/entities/{$entity_name}/entity.inc.php");
  		if(isset($entity) && is_array($entity))
  		{
  			$db_forms = array_merge($db_forms, $entity);
  		}
  	}
  }
  
  /**
   * Include all entities params
   * Подключает параметры всех сущностей в сответствии с сортировкой 
   * (файл sort.xml в каталоге сущности, 
   * если файла нет то сущность добавляется в конец списка)
   */
  function IncludeAllEntities()
  {
  	global $db_forms;
  	$entity_name_array = array();
  	
  	$sort_none = 100000;
  	
  	if(!file_exists($this->root."configuration/system/entities")
  	|| !file_exists($this->root."configuration/entities") )
  	{
  		return;
  	}
  	
  	$d = dir($this->root."configuration/system/entities");
  	while (false !== ($entry = $d->read())) 
  	{
  		if($entry == "." || $entry == "..")
  		{
  			continue;
			}
			if(!in_array($entry, $entity_name_array))
			{
				$sort_value = false;
				if(file_exists($this->root."configuration/system/entities/{$entry}/sort.xml"))
				{
					$xmlDoc = new DOMDocument();
					$xmlDoc->load($this->root."configuration/system/entities/{$entry}/sort.xml");
					$x=$xmlDoc->getElementsByTagName('sort');
					if($x->length && $x->item(0)->nodeValue)
					{
						$sort_value = intval($x->item(0)->nodeValue);
					}
					unset($x);
					unset($xmlDoc);
 					
				}
				if($sort_value)
				{
					$entity_name_array[$sort_value] = $entry;
				}
				else 
				{
					$entity_name_array[$sort_none++] = $entry;
				}
			}
		}
		$d->close();
		unset($d);

  	$d = dir($this->root."configuration/entities");
  	while (false !== ($entry = $d->read())) 
  	{
  		if($entry == "." || $entry == "..")
  		{
  			continue;
			}
			if(!in_array($entry, $entity_name_array))
			{
				$sort_value = false;
				if(file_exists($this->root."configuration/entities/{$entry}/sort.xml"))
				{
					$xmlDoc = new DOMDocument();
					$xmlDoc->load($this->root."configuration/entities/{$entry}/sort.xml");
					$x=$xmlDoc->getElementsByTagName('sort');
					if($x->length && $x->item(0)->nodeValue)
					{
						$sort_value = intval($x->item(0)->nodeValue);
					}
					unset($x);
					unset($xmlDoc);
 					
				}
				if($sort_value)
				{
					$entity_name_array[$sort_value] = $entry;
				}
				else 
				{
					$entity_name_array[$sort_none++] = $entry;
				}
				
			}
		}
		$d->close();
		unset($d);
		
		
		ksort($entity_name_array);
		
		$db_forms = array();
		
		var_dump($entity_name_array);
		
		
		foreach ($entity_name_array as $entity_name)
		{
			$this->IncludeEntity($entity_name);
		}
		
		var_dump($db_forms);
  }

}

?>