<?
//-----------------------------------------------------------------------------
// Файл основной функциональности административного интерфейса

//-----------------------------------------------------------------------------
// Функция авторизации
function auth_user($user, $password)
{
  // проверим суперадмина
  if($user == ADMIN_USER && $password == ADMIN_PASSWORD)
  {
    return true;
  }
  // проверим обычного пользователя
  $adminuser = new CEntity(
  	array(
  		"table" => "adminuser",
  		"index_suffix" => "ln",
  		"id" => $user
  	)
  );
  /*
  $adminuser = new EntityClass( 
    "adminuser", 
    'none', 
    "d.m.Y",
    array(), 
    array(),
    array("adminuser_ln","adminuser_password"),
    array(),
    $user,
    "ln",
    array(),
    array("adminuser_ln", "adminuser_password", "adminuser_fullname", "adminuser_comment", "adminuser_pages") );
  */
  //if($adminuser->entity_id == $user && $adminuser->headers["adminuser_password"] == $password)
  if($adminuser->identity 
  && $adminuser->entity_id == $user && $adminuser->GetHeader("adminuser_password") == $password)
  {
    return true;
  }
  return false;
}

//-----------------------------------------------------------------------------
// Функция проверки разрешения доступа пользователя к странице
function auth_user_page($user,$password,$page)
{
  global $file_names;
  // проверим суперадмина
  if($user == ADMIN_USER && $password == ADMIN_PASSWORD)
  {
    return true;
  }
  // проверим права пользователя
  auth_file_names($user,$password);

  if($page == "index.php"
	|| $page == "editor.php" 
	|| $page == "image.php" 
	|| $page == "help.php" 
	|| $page == "about.php" 
	|| $page == "hyperlink.php" 
	|| in_array($page, array_keys($file_names)))
  {
    return true;
  }
  
  return false;
}

// Функция проверяет права доступа пользователя к страницам и удаляет 
// из массива $file_names те страницы к которым у пользоваетля нет доступа
function auth_file_names($user,$password)
{
  global $file_names;
  // проверим суперадмина
  if($user == ADMIN_USER && $password == ADMIN_PASSWORD)
  {
    // суперадмину можно все
    return;
  }

  // проверим обычного пользователя
  $adminuser = new CEntity(
  	array(
  		"table" => "adminuser",
  		"index_suffix" => "ln",
  		"id" => $user
  	)
  );
  /*
  $adminuser = new EntityClass( 
    "adminuser", 
    'none', 
    "d.m.Y",
    array(), 
    array(),
    array("adminuser_ln","adminuser_password"),
    array("adminuser_pages"),
    $user,
    "ln",
    array(),
    array("adminuser_ln", "adminuser_password", "adminuser_fullname", "adminuser_comment", "adminuser_pages") );
  */

	if(!$adminuser->identity)
  {
    // не нашли пользователя
    // удалим содержимое массива
    $file_names = array();
    return;
  }

  //$pages = preg_split("/(?im)[\\n\\r\\s\\t]+/", $adminuser->texts["adminuser_pages"]);
  $pages = preg_split("/(?im)[\\n\\r\\s\\t]+/", $adminuser->GetText("adminuser_pages"));
  foreach($file_names as $key=>$value)
  {
    if ($key != "index.php" && !in_array($key, $pages)) 
    {
      // удалим страницу из списка доступных страниц
      unset($file_names[$key]);
    }
  }
  return;
}

//-----------------------------------------------------------------------------
// Функция передвигает строку заданной таблицы вверх или вниз
//  $table      - имя таблицы
//  $id         - идентификатор строки
//  $current_order - текущее значение поля $table_order
//  $updown     - признак куда перемещать "up" | "down"
//  $id_field   - имя поля идентификатора
//  $parent_id  - родитель строки
//  $parent_field - имя поля родителя
function admin_move_updown($table, $id, $current_order,
$updown, $id_field="id", $parent_id="", $parent_field="parent", $parent_id_field="id")
{
  $tempvalue = 100000;


  // найдем строку до или после текущей строки
  $query = "
SELECT " . $table . "_" . $id_field . ", ". $table . "_order
FROM  " . DATABASE_PREFIX . $table . "
WHERE NULL IS NULL
AND " . $table . "_" . $id_field . " = '" .$id. "'";

  if($parent_id != "")
  {
    $query .= "
AND " . $parent_field . " = '" . $parent_id . "'";
  }
  // нужна только одна строка
  $query .= "
LIMIT 0,1
";

//var_dump($query);exit;

  $db = new CDatabase();
  $db->Query($query);
  
  //$result = mysql_query($query) or die(die_mysql_error_show($query));
  //if($result && $row = mysql_fetch_assoc($result))
  if($row = $db->NextAssoc())
  {
    $current_order = $row[$table . "_order"];
    //var_dump($current_order);exit;

    // найдем строку до или после текущей строки
    $query = "
SELECT " . $table . "_" . $id_field . ", ". $table . "_order
FROM  " . DATABASE_PREFIX . $table . "
WHERE NULL IS NULL";

    if($parent_id != "")
    {
      $query .= "
AND " . $parent_field . " = '" . $parent_id . "'";
    }
    switch($updown)
    {
      case "up":
        $query .= "
AND " . $table . "_order < '" . $current_order . "'";
        break;
      case "down":
        $query .= "
AND " . $table . "_order > '" . $current_order . "'";
        break;
      default:
        $query .= "
AND NULL IS NOT NULL";
    }
    // нужна только одна строка
    $query .= "
ORDER BY " . $table . "_order " . ($updown=="up"?"DESC":"ASC") . "
LIMIT 0,1
";

//var_dump($query);exit;

    $result = mysql_query($query) or die(die_mysql_error_show($query));
    if($result && $row = mysql_fetch_assoc($result))
    {

      $prevnext_id  = $row[$table . "_" . $id_field];
      $prevnext_order  = $row[$table . "_order"];

//var_dump($id);
//var_dump($prevnext_id);
//var_dump($current_order);
//var_dump($prevnext_order);
//exit(0);
      // поменяем строки местами
      $temp = $current_order;
      $current_order = $prevnext_order;
      $prevnext_order = $temp;

      // поменяем местами
      $query = "
UPDATE " . DATABASE_PREFIX . $table . " SET ". $table . "_order = '" . $prevnext_order . "'
WHERE ". $table. "_" . $id_field ." = '" . $prevnext_id . "';";
//var_dump($query);
			$db->Query($query);
      //mysql_query($query) or die(die_mysql_error_show($query));

      $query = "
UPDATE " . DATABASE_PREFIX . $table . " SET " . $table . "_order = '" . $current_order . "'
WHERE " . $table . "_" . $id_field . " = '" . $id . "';";
//var_dump($query);
      //mysql_query($query) or die(die_mysql_error_show($query));
			$db->Query($query);
      //exit(0);

    }

  }

  //admin_reorder_table($table, $id_field="id", $parent_id="", $parent_field="id");

}


function admin_reorder_table($table, $id_field="id", $parent_id="", $parent_field="id")
{
  // сделаем все записи попорядку
  $query = "
SELECT ". $table . "_" . $id_field . ", IF(ISNULL(". $table . "_order)=1,1000000000, ". $table . "_order) AS ". $table . "_order
FROM  " . DATABASE_PREFIX . $table . "
WHERE NULL IS NULL";


  if($parent_id != "")
  {
    $query .= "
AND $parent_field = '$parent_id'";
  }

$query .= "
ORDER BY " . $table . "_order ASC;";

//var_dump($query);
  $order = 1;
  //$result = mysql_query($query) or die(die_mysql_error_show($query));
  $db=new CDatabase();
  $result = $db->Query($query);
  $query_reorder = "";
  while($result && $row = $db->NextAssoc($result))
  {
    $current_id = $row[$table . "_" . $id_field];
    $query_reorder = "

UPDATE " . DATABASE_PREFIX . $table . " SET " . $table . "_order = '" . $order . "'
WHERE " . $table . "_" . $id_field . " = '" . $current_id . "';";
    $order++;

    $db1=new CDatabase();
    $result = $db1->Query($query_reorder);
    //var_dump($query);
    //mysql_query($query_reorder) or die(die_mysql_error_show($query));
  }
}

function admin_reorder_table_recursion($table, $parent_id, $parent_field)
{
  // сделаем все записи попорядку
  $query = "
SELECT ". $table . "_id, IF(ISNULL(". $table . "_order)=1,1000000000, ". $table . "_order) AS ". $table . "_order
FROM  " . DATABASE_PREFIX . $table . "
WHERE NULL IS NULL";

  //if($parent_id != "")
  {
//echo ("@@@@@@@@@@@@");
    $query .= "
AND ($parent_field = '$parent_id'";
    if($parent_id == "0")
    {
      $query .= " OR $parent_field IS NULL";
    }
    $query .= ")";
  }

$query .= "
ORDER BY " . $table . "_order ASC;";

//var_dump($query);exit;


  $order = 1;
  $db = new CDatabase();
  //var_dump($db->Query($query));
  $db->Query($query);
  //$result = mysql_query($query) or die(die_mysql_error_show($query));
  $query_reorder = "";
  //while($result && $row = mysql_fetch_assoc($result))
  while($row = $db->NextAssoc())
  {
    $current_id = $row[$table . "_id"];
    $query_reorder = "
UPDATE " . DATABASE_PREFIX . $table . " SET " . $table . "_order = '" . $order . "'
WHERE " . $table . "_id" . " = '" . $current_id . "';";
    $order++;
    
    $db2 = new CDatabase();
    $db2->Query($query_reorder);
    $db2->Free();
    //mysql_query($query_reorder) or die(die_mysql_error_show($query));
//var_dump($query_reorder);exit;
    admin_reorder_table_recursion($table, $row[$table . "_id"], $parent_field);
  }
  $db->Free();
}

?>
